/**
* Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <smithy/client/AwsSmithyClientBase.h>
#include <smithy/client/AwsSmithyClientAsyncRequestContext.h>
#include <smithy/client/features/RecursionDetection.h>
#include <smithy/client/features/RequestPayloadCompression.h>
#include <smithy/identity/signer/built-in/SignerProperties.h>
#include <smithy/tracing/TracingUtils.h>

#include <aws/core/client/AWSErrorMarshaller.h>
#include <aws/core/client/AsyncOperationState.h>
#include <aws/core/client/CoreErrors.h>
#include <aws/core/internal/ClockSkew.h>
#include <aws/core/client/RetryStrategy.h>
#include <aws/core/http/HttpClientFactory.h>
#include <aws/core/monitoring/CoreMetrics.h>
#include <aws/core/monitoring/MonitoringManager.h>
#include <aws/core/platform/Environment.h>
#include <aws/core/utils/DNS.h>
#include <aws/core/utils/StringUtils.h>
#include <aws/core/utils/logging/ErrorMacros.h>
#include <aws/core/utils/stream/ResponseStream.h>
#include <aws/core/utils/threading/Executor.h>
#include <aws/core/utils/threading/SameThreadExecutor.h>
#include <aws/crt/Variant.h>
#include <smithy/identity/auth/built-in/GenericAuthSchemeResolver.h>
#include <smithy/identity/auth/built-in/SigV4aAuthSchemeOption.h>

using namespace smithy::client;
using namespace smithy::client::features;
using namespace smithy::interceptor;
using namespace smithy::components::tracing;

static const char AWS_SMITHY_CLIENT_LOG[] = "AwsSmithyClient";

namespace smithy {
    SMITHY_API const char *SIGNER_REGION_PROPERTY = "signerRegionOverride";
    SMITHY_API const char *SIGNER_SERVICE_NAME = "signerServiceNameOverride";
}

namespace {
void AddHeadersToRequest(const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest,
    const Aws::Http::HeaderValueCollection& headerValues)
{
  for (auto const& headerValue : headerValues)
  {
    httpRequest->SetHeaderValue(headerValue.first, headerValue.second);
  }
}

template <typename T>
void createFromFactories(T& entity, std::function<T()>& factory) {
  if (!entity) {
    assert(factory);
    entity = factory();
  } else {
    factory = nullptr;
  }
}

template <typename T>
void createFromFactoriesIfPresent(T& entity, std::function<T()>& factory) {
  if (entity && factory) {
    entity = factory();
  }
}
}  // namespace

void AwsSmithyClientBase::baseInit() {
  AWS_CHECK_PTR(AWS_SMITHY_CLIENT_LOG, m_clientConfig);
  m_clientSkew = Aws::MakeShared<Aws::Internal::ClientSkew>(AWS_SMITHY_CLIENT_LOG, std::chrono::milliseconds(0));
  createFromFactories(m_clientConfig->retryStrategy, m_clientConfig->configFactories.retryStrategyCreateFn);
  createFromFactories(m_clientConfig->executor, m_clientConfig->configFactories.executorCreateFn);
  createFromFactories(m_clientConfig->writeRateLimiter, m_clientConfig->configFactories.writeRateLimiterCreateFn);
  createFromFactories(m_clientConfig->readRateLimiter, m_clientConfig->configFactories.readRateLimiterCreateFn);
  createFromFactories(m_clientConfig->telemetryProvider, m_clientConfig->configFactories.telemetryProviderCreateFn);
  if (m_clientConfig && m_clientConfig->retryStrategy) {
    m_userAgentInterceptor = Aws::MakeShared<UserAgentInterceptor>(AWS_SMITHY_CLIENT_LOG,
                                                                      *m_clientConfig,
                                                                      m_clientConfig->retryStrategy->GetStrategyName(),
                                                                      m_serviceUserAgentName);
    m_interceptors.emplace_back(m_userAgentInterceptor);
  }
}

void AwsSmithyClientBase::baseCopyInit() {
  AWS_CHECK_PTR(AWS_SMITHY_CLIENT_LOG, m_clientConfig);
  m_clientSkew = Aws::MakeShared<Aws::Internal::ClientSkew>(AWS_SMITHY_CLIENT_LOG, std::chrono::milliseconds(0));
  createFromFactoriesIfPresent(m_clientConfig->retryStrategy, m_clientConfig->configFactories.retryStrategyCreateFn);
  createFromFactoriesIfPresent(m_clientConfig->executor, m_clientConfig->configFactories.executorCreateFn);
  createFromFactoriesIfPresent(m_clientConfig->writeRateLimiter, m_clientConfig->configFactories.writeRateLimiterCreateFn);
  createFromFactoriesIfPresent(m_clientConfig->readRateLimiter, m_clientConfig->configFactories.readRateLimiterCreateFn);
  createFromFactoriesIfPresent(m_clientConfig->telemetryProvider, m_clientConfig->configFactories.telemetryProviderCreateFn);
  if (m_clientConfig && m_clientConfig->retryStrategy) {
    m_userAgentInterceptor = Aws::MakeShared<UserAgentInterceptor>(AWS_SMITHY_CLIENT_LOG,
                                                                      *m_clientConfig,
                                                                      m_clientConfig->retryStrategy->GetStrategyName(),
                                                                      m_serviceUserAgentName);
    m_interceptors.emplace_back(m_userAgentInterceptor);
  }
}

void AwsSmithyClientBase::baseCopyAssign(const AwsSmithyClientBase& other,
                                         std::shared_ptr<Aws::Http::HttpClient> httpClient,
                                         std::shared_ptr<Aws::Client::AWSErrorMarshaller> errorMarshaller) {
  m_serviceName = other.m_serviceName;
  m_serviceUserAgentName = other.m_serviceUserAgentName;
  m_httpClient = std::move(httpClient);
  m_errorMarshaller = std::move(errorMarshaller);
  
  m_interceptors = Aws::Vector<std::shared_ptr<interceptor::Interceptor>>{
      Aws::MakeShared<ChecksumInterceptor>("AwsSmithyClientBase", *m_clientConfig),
      Aws::MakeShared<features::ChunkingInterceptor>("AwsSmithyClientBase", 
          m_httpClient->IsDefaultAwsHttpClient() ? Aws::Client::HttpClientChunkedMode::DEFAULT : m_clientConfig->httpClientChunkedMode,
          m_clientConfig->awsChunkedBufferSize)
  };

  baseCopyInit();
}

void AwsSmithyClientBase::baseMoveAssign(AwsSmithyClientBase&& other) {
  m_clientSkew = Aws::MakeShared<Aws::Internal::ClientSkew>(AWS_SMITHY_CLIENT_LOG, std::chrono::milliseconds(0));
  m_serviceName = std::move(other.m_serviceName);
  m_serviceUserAgentName = std::move(other.m_serviceUserAgentName);
  m_httpClient = std::move(other.m_httpClient);
  m_errorMarshaller = std::move(other.m_errorMarshaller);
  m_interceptors = std::move(other.m_interceptors);
  m_userAgentInterceptor = std::move(other.m_userAgentInterceptor);
}

std::shared_ptr<Aws::Http::HttpRequest>
AwsSmithyClientBase::BuildHttpRequest(const std::shared_ptr<AwsSmithyClientAsyncRequestContext>& pRequestCtx,
                                      const Aws::Http::URI& uri,
                                      Aws::Http::HttpMethod method
                                      ) const
{
    assert(pRequestCtx);
    std::shared_ptr<HttpRequest> httpRequest;
    const auto* pRequest = pRequestCtx->m_pRequest;
    if(pRequest) {
        httpRequest = CreateHttpRequest(uri, method, pRequest->GetResponseStreamFactory());
    } else {
        httpRequest = CreateHttpRequest(uri, method, Aws::Utils::Stream::DefaultResponseStreamFactoryMethod);
    }
    if (!httpRequest)
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Failed to allocate an HttpRequest under a shared ptr");
        return httpRequest;
    }

    httpRequest->SetHeaderValue(Aws::Http::SDK_INVOCATION_ID_HEADER, pRequestCtx->m_invocationId);
    httpRequest->SetHeaderValue(Aws::Http::SDK_REQUEST_HEADER, pRequestCtx->m_requestInfo.ToString());
    RecursionDetection::AppendRecursionDetectionHeader(pRequestCtx->m_httpRequest);

    if (pRequest)
    {
        AddHeadersToRequest(httpRequest, pRequest->GetHeaders());
        AddHeadersToRequest(httpRequest, pRequest->GetAdditionalCustomHeaders());

        httpRequest->SetHasEventStreamResponse(pRequest->HasEventStreamResponse());

        if (pRequest->IsEventStreamRequest())
        {
            httpRequest->SetEventStreamRequest(true);
            httpRequest->AddContentBody(pRequest->GetBody());
        }
        else
        {
            //Check if compression is required
            Aws::Client::CompressionAlgorithm selectedCompressionAlgorithm = pRequest->GetSelectedCompressionAlgorithm(m_clientConfig->requestCompressionConfig);
            if (Aws::Client::CompressionAlgorithm::NONE != selectedCompressionAlgorithm) {
                RequestPayloadCompression::AddCompressedContentBodyToRequest(pRequest, httpRequest, selectedCompressionAlgorithm, m_httpClient);
            } else {
                Utils::AddContentBodyToRequest(httpRequest, pRequest->GetBody(), m_httpClient,
                                               pRequest->ShouldComputeContentMd5(), pRequest->IsStreaming() && pRequest->IsChunked());
            }
        }

        if (pRequest->IsStreaming() && !m_clientConfig->disableExpectHeader)
        {
            httpRequest->SetHeaderValue(Aws::Http::EXPECT_HEADER, Aws::Http::EXPECT_100_CONTINUE_VALUE);
        }

        // Pass along handlers for processing data sent/received in bytes
        httpRequest->SetHeadersReceivedEventHandler(pRequest->GetHeadersReceivedEventHandler());
        httpRequest->SetDataReceivedEventHandler(pRequest->GetDataReceivedEventHandler());
        httpRequest->SetDataSentEventHandler(pRequest->GetDataSentEventHandler());
        httpRequest->SetContinueRequestHandle(pRequest->GetContinueRequestHandler());
        httpRequest->SetServiceSpecificParameters(pRequest->GetServiceSpecificParameters());

        pRequest->AddQueryStringParameters(httpRequest->GetUri());
    }

    return httpRequest;
}


bool AwsSmithyClientBase::ResolveIdentityAuth(
    std::shared_ptr<AwsSmithyClientAsyncRequestContext>& pRequestCtx,
    ResponseHandlerFunc&& responseHandler,
    EndpointUpdateCallback&& endpointCallback
) const
{

    auto authSchemeOptionOutcome = this->SelectAuthSchemeOption(*pRequestCtx);
    if (!authSchemeOptionOutcome.IsSuccess())
    {
        responseHandler(std::move(authSchemeOptionOutcome));
        return false;
    }
    pRequestCtx->m_authSchemeOption = std::move(authSchemeOptionOutcome.GetResultWithOwnership());
    assert(pRequestCtx->m_authSchemeOption.schemeId);

    // resolve identity
    auto identityOutcome = this->ResolveIdentity(*pRequestCtx);
    if (!identityOutcome.IsSuccess())
    {
      responseHandler(std::move(identityOutcome));
      return false;
    }
    for (auto feature : identityOutcome.GetResult()->GetUserAgentFeatures()) {
       pRequestCtx->m_pRequest->AddUserAgentFeature(feature);
    }
    pRequestCtx->m_awsIdentity = std::move(identityOutcome.GetResultWithOwnership());



    // get endpoint params from operation context
    const auto contextEndpointParameters = this->GetContextEndpointParameters(*pRequestCtx);

    if (!contextEndpointParameters.IsSuccess())
    {
      responseHandler(std::move(contextEndpointParameters.GetError()));

      return false;
    }

    Aws::Endpoint::EndpointParameters epParams = pRequestCtx->m_pRequest ? pRequestCtx->m_pRequest->GetEndpointContextParams() : Aws::Endpoint::EndpointParameters();
    const auto authSchemeEpParams = pRequestCtx->m_authSchemeOption.endpointParameters();
    epParams.insert(epParams.end(), authSchemeEpParams.begin(), authSchemeEpParams.end());
    const auto contextParams = contextEndpointParameters.GetResult();
    epParams.insert(epParams.end(), contextParams.begin(), contextParams.end());
    auto epResolutionOutcome = this->ResolveEndpoint(std::move(epParams), std::move(endpointCallback));
    if (!epResolutionOutcome.IsSuccess())
    {
        auto epOutcome = ResolveEndpointOutcome(Aws::Client::AWSError<Aws::Client::CoreErrors>{
            Aws::Client::CoreErrors::ENDPOINT_RESOLUTION_FAILURE,
            epResolutionOutcome.GetError().GetExceptionName(),
            epResolutionOutcome.GetError().GetMessage(),
            false});
        responseHandler(std::move(epOutcome));
        return false;
    }
    pRequestCtx->m_endpoint = std::move(epResolutionOutcome.GetResultWithOwnership());
    if (!Aws::Utils::IsValidHost(pRequestCtx->m_endpoint.GetURI().GetAuthority()))
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Invalid DNS Label found in URI host");
        auto outcome = HttpResponseOutcome(ClientError(CoreErrors::VALIDATION, "", "Invalid DNS Label found in URI host", false/*retryable*/));
        responseHandler(std::move(outcome));
        return false;
    }
    return true;
}

void AwsSmithyClientBase::MakeRequestAsync(Aws::AmazonWebServiceRequest const* const request,
                                           const char* requestName,
                                           Aws::Http::HttpMethod method,
                                           EndpointUpdateCallback&& endpointCallback,
                                           ResponseHandlerFunc&& responseHandler,
                                           AuthResolvedCallback&& authCallback,
                                           std::shared_ptr<Aws::Utils::Threading::Executor> pExecutor) const
{
    const auto pRequestCtx = CreateRequestContext(request, requestName, method, std::move(endpointCallback), std::move(responseHandler), std::move(authCallback), std::move(pExecutor));
    if (!pRequestCtx)
    {
        return;
    }
#if defined(AWS_CRT_HTTP_USE_ASYNC_IO)
    RunAttemptsAsync(pRequestCtx);
#else
    RunAttemptsBlocking(pRequestCtx);
#endif
}

std::shared_ptr<AwsSmithyClientAsyncRequestContext> AwsSmithyClientBase::CreateRequestContext(Aws::AmazonWebServiceRequest const* const request,
                                                                                              const char* requestName,
                                                                                              Aws::Http::HttpMethod method,
                                                                                              EndpointUpdateCallback&& endpointCallback,
                                                                                              ResponseHandlerFunc&& responseHandler,
                                                                                              AuthResolvedCallback&& authCallback,
                                                                                              std::shared_ptr<Aws::Utils::Threading::Executor> pExecutor) const
{
    if (!pExecutor)
    {
        pExecutor = m_clientConfig->executor;
    }
    if(!responseHandler)
    {
        assert(!"Missing a mandatory response handler!");
        AWS_LOGSTREAM_FATAL(AWS_SMITHY_CLIENT_LOG, "Unable to continue AWSClient request: response handler is missing!");
        return nullptr;
    }
    auto authResolver = request->GetRequestSpecificSupportedAuth().empty() ? nullptr : Aws::MakeShared<GenericAuthSchemeResolver<>>(AWS_SMITHY_CLIENT_LOG, request->GetRequestSpecificSupportedAuth());
    std::shared_ptr<AwsSmithyClientAsyncRequestContext> pRequestCtx =
        Aws::MakeShared<AwsSmithyClientAsyncRequestContext>(AWS_SMITHY_CLIENT_LOG, request, requestName, pExecutor, authResolver);
    if (!pRequestCtx)
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Failed to allocate an AwsSmithyClientAsyncRequestContext under a shared ptr");
        auto outcome = HttpResponseOutcome(ClientError(CoreErrors::MEMORY_ALLOCATION, "", "Failed to allocate async request context", false/*retryable*/));
        pExecutor->Submit([outcome, responseHandler]() mutable
          {
              responseHandler(std::move(outcome));
          } );
        return nullptr;
    }

    pRequestCtx->m_method = method;
    ResponseHandlerFunc modifiedResponseHandler = [&](HttpResponseOutcome&& outcome){
        auto capturedOutcome = std::make_shared<HttpResponseOutcome>(std::move(outcome));
        pExecutor->Submit([capturedOutcome, responseHandler]()
        {
            responseHandler(std::move(*capturedOutcome));
        });
    };

    if(!ResolveIdentityAuth(
        pRequestCtx,
        std::move(modifiedResponseHandler),
        std::move(endpointCallback)))
    {
        return nullptr;
    }
    pRequestCtx->m_requestInfo.attempt = 1;
    pRequestCtx->m_attemptSkew = m_clientSkew->Load();
    pRequestCtx->m_requestInfo.maxAttempts =
        Aws::Environment::GetEnv("AWS_NEW_RETRIES_2026") == "true"
            ? m_clientConfig->retryStrategy->GetMaxAttempts()
            : 0;
    pRequestCtx->m_interceptorContext = Aws::MakeShared<InterceptorContext>(AWS_SMITHY_CLIENT_LOG, *request);
    pRequestCtx->m_responseHandler = std::move(responseHandler);
    pRequestCtx->m_authResolvedCallback = std::move(authCallback);
    return pRequestCtx;
}

#if defined(AWS_CRT_HTTP_USE_ASYNC_IO)
void AwsSmithyClientBase::RunAttemptsAsync(const std::shared_ptr<AwsSmithyClientAsyncRequestContext>& pRequestCtx) const
{
    const AwsSmithyClientBase* self = this;
    auto prepareAttempt = [self, pRequestCtx]() -> std::shared_ptr<Aws::Http::HttpRequest>
    {
        return self->AttemptOneRequestAsync(pRequestCtx);
    };
    auto evaluateAttempt = [self, pRequestCtx](std::shared_ptr<Aws::Http::HttpResponse> httpResponse) -> Aws::Http::HttpClient::AttemptOutcome
    {
        return self->HandleAsyncReply(pRequestCtx, std::move(httpResponse));
    };
    auto onComplete = [pRequestCtx]()
    {
        pRequestCtx->m_responseHandler(std::move(pRequestCtx->m_outcome));
    };

    pRequestCtx->m_outcome = HttpResponseOutcome(ClientError(CoreErrors::USER_CANCELLED, "", "Request cancelled before completion", false/*retryable*/));
    auto error = m_httpClient->MakeRequestAsync(prepareAttempt, evaluateAttempt, onComplete, pRequestCtx->m_pExecutor);
    if (error.has_value())
    {
        pRequestCtx->m_outcome = HttpResponseOutcome(*error);
        onComplete();
    }
}
#endif

void AwsSmithyClientBase::RunAttemptsBlocking(const std::shared_ptr<AwsSmithyClientAsyncRequestContext>& pRequestCtx) const
{
    const AwsSmithyClientBase* self = this;
    auto prepareAttempt = [self, pRequestCtx]() -> std::shared_ptr<Aws::Http::HttpRequest>
    {
        return self->AttemptOneRequestAsync(pRequestCtx);
    };
    auto evaluateAttempt = [self, pRequestCtx](std::shared_ptr<Aws::Http::HttpResponse> httpResponse) -> Aws::Http::HttpClient::AttemptOutcome
    {
        return self->HandleAsyncReply(pRequestCtx, std::move(httpResponse));
    };
    auto onComplete = [pRequestCtx]()
    {
        pRequestCtx->m_pExecutor->Submit([pRequestCtx]()
        {
            pRequestCtx->m_responseHandler(std::move(pRequestCtx->m_outcome));
        });
    };

    for (std::shared_ptr<Aws::Http::HttpRequest> httpRequest = prepareAttempt(); httpRequest; httpRequest = prepareAttempt())
    {
        auto httpResponse = TracingUtils::MakeCallWithTiming<std::shared_ptr<Aws::Http::HttpResponse>>(
            [&]() -> std::shared_ptr<Aws::Http::HttpResponse> {
                return m_httpClient->MakeRequest(httpRequest, m_clientConfig->readRateLimiter.get(), m_clientConfig->writeRateLimiter.get());
            },
            TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC,
            *m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
             {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        auto outcome = evaluateAttempt(std::move(httpResponse));
        if (!outcome.shouldRetry)
        {
            if (outcome.backoff.count() > 0)
            {
                m_httpClient->RetryRequestSleep(outcome.backoff);
            }
            break;
        }
        m_httpClient->RetryRequestSleep(outcome.backoff);
    }
    onComplete();
}

void AwsSmithyClientBase::UpdateAuthSchemeFromEndpoint(const Aws::Endpoint::AWSEndpoint& endpoint, smithy::AuthSchemeOption& authscheme) const
{
    //Overrides from endpoint
    if (endpoint.GetAttributes()) {
        auto authschemeName = endpoint.GetAttributes()->authScheme.GetName();
        if (endpoint.GetAttributes()->authScheme.GetSigningRegion()) {
            auto signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegion();
            authscheme.putSignerProperty(smithy::SIGNER_REGION_PROPERTY, Aws::Crt::Variant<Aws::String, bool>(Aws::String(signerRegionOverride->c_str())));
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningRegionSet()) {
            auto signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegionSet();
            authscheme.putSignerProperty(smithy::SIGNER_REGION_PROPERTY, Aws::Crt::Variant<Aws::String, bool>(Aws::String(signerRegionOverride->c_str())));
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningName()) {
            auto signerServiceNameOverride = endpoint.GetAttributes()->authScheme.GetSigningName();
            authscheme.putSignerProperty(smithy::SIGNER_SERVICE_NAME, Aws::Crt::Variant<Aws::String, bool>(Aws::String(signerServiceNameOverride->c_str())));
        }
    }
    // If a value is explicitly set in configuration, it must be used over values defined anywhere else (ONLY FOR SigV4a)
    if (strcmp(authscheme.schemeId, SigV4aAuthSchemeOption::sigV4aAuthSchemeOption.schemeId) == 0 && !m_clientConfig->sigV4aSigningRegionSet.empty()) {
        authscheme.putSignerProperty(smithy::SIGNER_REGION_PROPERTY,
            Aws::Crt::Variant<Aws::String, bool>(Aws::Utils::StringUtils::Join(m_clientConfig->sigV4aSigningRegionSet, ',')));
    }
}


/*HttpResponseOutcome*/
std::shared_ptr<Aws::Http::HttpRequest> AwsSmithyClientBase::AttemptOneRequestAsync(std::shared_ptr<AwsSmithyClientAsyncRequestContext> pRequestCtx) const
{
    if(!pRequestCtx)
    {
        assert(!"Missing pRequestCtx");
        AWS_LOGSTREAM_FATAL(AWS_SMITHY_CLIENT_LOG, "Missing request context!");
    }
    auto& authCallback = pRequestCtx->m_authResolvedCallback;

    //This is extracted here so that on retry with correct region, signer region override is honored
    UpdateAuthSchemeFromEndpoint(pRequestCtx->m_endpoint, pRequestCtx->m_authSchemeOption);

    TracingUtils::MakeCallWithTiming(
      [&]() -> void {
          pRequestCtx->m_httpRequest = BuildHttpRequest(pRequestCtx, pRequestCtx->m_endpoint.GetURI(), pRequestCtx->m_method);
      },
      TracingUtils::SMITHY_CLIENT_SERIALIZATION_METRIC,
      *m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
      {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
       {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    if (!pRequestCtx->m_httpRequest)
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Failed to BuildHttpRequest");
        pRequestCtx->m_outcome = HttpResponseOutcome(ClientError(CoreErrors::VALIDATION, "", "Unable to create HttpRequest object", false/*retryable*/));
        return nullptr;
    }

    pRequestCtx->m_interceptorContext->SetTransmitRequest(pRequestCtx->m_httpRequest);
    for (const auto& interceptor : m_interceptors)
    {
        auto modifiedRequest = interceptor->ModifyBeforeSigning(*pRequestCtx->m_interceptorContext);
        if (!modifiedRequest.IsSuccess())
        {
            pRequestCtx->m_outcome = HttpResponseOutcome(modifiedRequest.GetError());
            return nullptr;
        }
    }

    Aws::Monitoring::CoreMetricsCollection coreMetrics;
    pRequestCtx->m_monitoringContexts = Aws::Monitoring::OnRequestStarted(this->GetServiceClientName(),
                                                                          pRequestCtx->m_requestName,
                                                                          pRequestCtx->m_httpRequest);

    if(m_clientConfig->retryStrategy && !m_clientConfig->retryStrategy->HasSendToken())
    {
        pRequestCtx->m_outcome = HttpResponseOutcome(ClientError(CoreErrors::SLOW_DOWN, "", "Unable to acquire enough send tokens to execute request.", false/*retryable*/));
        return nullptr;
    };
    if (authCallback) {
      authCallback(pRequestCtx);
    }
    pRequestCtx->m_timeRequestSent = Aws::Utils::DateTime::Now();
    pRequestCtx->m_httpRequest->SetSigningTimestampOverride(pRequestCtx->m_timeRequestSent + pRequestCtx->m_attemptSkew);
    SigningOutcome signingOutcome = TracingUtils::MakeCallWithTiming<SigningOutcome>([&]() -> SigningOutcome {
            return this->SignHttpRequest(pRequestCtx->m_httpRequest, *pRequestCtx);
        },
        TracingUtils::SMITHY_CLIENT_SIGNING_METRIC,
        *m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
         {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    if (!signingOutcome.IsSuccess())
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Request signing failed. Returning error.");
        pRequestCtx->m_outcome = HttpResponseOutcome(ClientError(CoreErrors::CLIENT_SIGNING_FAILURE, "", "SDK failed to sign the request", false/*retryable*/));
        return nullptr;
    }

    std::shared_ptr<Aws::Http::HttpRequest> signedHttpRequest = signingOutcome.GetResultWithOwnership();
    assert(signedHttpRequest);

    if (pRequestCtx->m_pRequest && pRequestCtx->m_pRequest->GetRequestSignedHandler())
    {
        pRequestCtx->m_pRequest->GetRequestSignedHandler()(*signedHttpRequest);
    }

    for (const auto& interceptor : m_interceptors)
    {
      auto modifiedRequest = interceptor->ModifyBeforeTransmit(*pRequestCtx->m_interceptorContext);
      if (!modifiedRequest.IsSuccess())
      {
        pRequestCtx->m_outcome = HttpResponseOutcome(modifiedRequest.GetError());
        return nullptr;
      }
    }

    AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Request Successfully signed");
#if defined(AWS_CRT_HTTP_USE_ASYNC_IO)
    pRequestCtx->m_serviceCallTimer.emplace(TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC,
        m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        Aws::Map<Aws::String, Aws::String>{
            {TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
            {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
#endif
    return signedHttpRequest;
}

void AwsSmithyClientBase::RecordClockSkew(const Aws::Http::HttpResponse& response, const AwsSmithyClientAsyncRequestContext& ctx) const
{
    if (m_clientConfig->enableClockSkewAdjustment)
    {
        m_clientSkew->RecordResponse(Aws::Internal::MakeClockSkewMeasurement(response.GetHeaders(), ctx.m_timeRequestSent, ctx.m_timeResponseReceived));
    }
}

bool AwsSmithyClientBase::AdjustClockSkew(HttpResponseOutcome& outcome, const AwsSmithyClientAsyncRequestContext& ctx) const
{
    if (!m_clientConfig->enableClockSkewAdjustment)
    {
        return false;
    }
    const auto measurement = Aws::Internal::MakeClockSkewMeasurement(outcome.GetError().GetResponseHeaders(), ctx.m_timeRequestSent, ctx.m_timeResponseReceived);
    const auto adjustment = m_clientSkew->EvaluateFailure(measurement, ctx.m_attemptSkew);
    // Force a retry only when the error is a clock-skew error code and the skew exceeds the threshold.
    if (Aws::Internal::IsClockSkewError(outcome.GetError()) && adjustment.skewExceedsThreshold)
    {
        AWS_LOGSTREAM_WARN(AWS_SMITHY_CLIENT_LOG, "Signature check likely failed due to clock skew; adjusting the signing timestamp and retrying.");
        auto newError = outcome.GetError();
        newError.SetRetryableType(Aws::Client::RetryableType::RETRYABLE);
        outcome = std::move(newError);
        return true;
    }
    return false;
}

Aws::Http::HttpClient::AttemptOutcome AwsSmithyClientBase::HandleAsyncReply(std::shared_ptr<AwsSmithyClientAsyncRequestContext> pRequestCtx,
                                           std::shared_ptr<Aws::Http::HttpResponse> httpResponse) const
{
    assert(pRequestCtx && httpResponse);

    pRequestCtx->m_timeResponseReceived = Aws::Utils::DateTime::Now();
#if defined(AWS_CRT_HTTP_USE_ASYNC_IO)
    pRequestCtx->m_serviceCallTimer.reset();
#endif

    pRequestCtx->m_interceptorContext->SetTransmitResponse(httpResponse);
    for (const auto& interceptor : m_interceptors)
    {
        const auto modifiedResponse = interceptor->ModifyBeforeDeserialization(*pRequestCtx->m_interceptorContext);
        if (!modifiedResponse.IsSuccess())
        {
            pRequestCtx->m_outcome = HttpResponseOutcome(modifiedResponse.GetError());
            return {};
        }
    };

    Aws::Client::HttpResponseOutcome outcome = [&]()
    {
        auto hasEmbeddedError = [&]() {
          return pRequestCtx->m_pRequest &&
          pRequestCtx->m_pRequest->HasEmbeddedError(httpResponse->GetResponseBody(), httpResponse->GetHeaders());
        };
        if (Utils::DoesResponseGenerateError(httpResponse))
        {
            AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Request returned error. Attempting to generate appropriate error codes from response");
            assert(m_errorMarshaller);
            auto error = m_errorMarshaller->BuildAWSError(httpResponse);
            return HttpResponseOutcome(std::move(error));
        }
        else if (hasEmbeddedError()) {
          AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Response has embedded errors");

          auto error = m_errorMarshaller->Marshall(*httpResponse);
          return HttpResponseOutcome(std::move(error) );
        }
        AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Request returned successful response.");
        return HttpResponseOutcome(std::move(httpResponse));
    } ();

    Aws::Monitoring::CoreMetricsCollection coreMetrics;
    std::chrono::milliseconds giveUpDelay{0};

    do // goto in a form of "do { break; } while(0);" // TODO: refactor
    {
        if (pRequestCtx->m_retryCount == 0)
        {
            m_clientConfig->retryStrategy->RequestBookkeeping(outcome);
        }
        else
        {
            assert(pRequestCtx->m_lastError);
            m_clientConfig->retryStrategy->RequestBookkeeping(outcome, pRequestCtx->m_lastError.value());
        }
        coreMetrics.httpClientMetrics = pRequestCtx->m_httpRequest->GetRequestMetrics();
        TracingUtils::EmitCoreHttpMetrics(pRequestCtx->m_httpRequest->GetRequestMetrics(),
            *m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
             {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        if (outcome.IsSuccess())
        {
            if (outcome.GetResult())
            {
                RecordClockSkew(*outcome.GetResult(), *pRequestCtx);
            }
            Aws::Monitoring::OnRequestSucceeded(this->GetServiceClientName(),
                                                pRequestCtx->m_requestName,
                                                pRequestCtx->m_httpRequest,
                                                outcome,
                                                coreMetrics,
                                                pRequestCtx->m_monitoringContexts);
            AWS_LOGSTREAM_TRACE(AWS_SMITHY_CLIENT_LOG, "Request successful returning.");
            break;
        }
        pRequestCtx->m_lastError = outcome.GetError();

        Utils::DateTime serverTime = Utils::GetServerTimeFromError(outcome.GetError());
        auto clockSkew = Utils::DateTime::Diff(serverTime, Utils::DateTime::Now());

        Aws::Monitoring::OnRequestFailed(this->GetServiceClientName(),
                                         pRequestCtx->m_requestName,
                                         pRequestCtx->m_httpRequest,
                                         outcome,
                                         coreMetrics,
                                         pRequestCtx->m_monitoringContexts);

        if (!m_httpClient->IsRequestProcessingEnabled())
        {
            AWS_LOGSTREAM_TRACE(AWS_SMITHY_CLIENT_LOG, "Request was cancelled externally.");
            break;
        }

        // Adjust region
        // TODO: extract into common func
        bool retryWithCorrectRegion = [&]() {
            using HttpResponseCode = Aws::Http::HttpResponseCode;
            const HttpResponseCode httpResponseCode = outcome.GetError().GetResponseCode();
            if (httpResponseCode == HttpResponseCode::MOVED_PERMANENTLY ||  // 301
                httpResponseCode == HttpResponseCode::TEMPORARY_REDIRECT || // 307
                httpResponseCode == HttpResponseCode::BAD_REQUEST ||        // 400
                httpResponseCode == HttpResponseCode::FORBIDDEN)            // 403
            {
              assert(m_errorMarshaller);
              const Aws::String regionFromResponse = m_errorMarshaller->ExtractRegion(outcome.GetError());
              const Aws::String signerRegion = [&]() {
                  if (!regionFromResponse.empty() &&
                      pRequestCtx->m_endpoint.GetAttributes() &&
                      pRequestCtx->m_endpoint.GetAttributes()->authScheme.GetSigningRegion())
                  {
                      return pRequestCtx->m_endpoint.GetAttributes()->authScheme.GetSigningRegion().value();
                  }
                  return Aws::String("");
              } ();
              if (m_clientConfig->region == Aws::Region::AWS_GLOBAL && !regionFromResponse.empty() &&
                  regionFromResponse != signerRegion) {
                pRequestCtx->m_endpoint.AccessAttributes()->authScheme.SetSigningRegion(regionFromResponse);
                AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Need to retry with a correct region");
                return true;
              }
            }
            return false;
        } (); // <- immediately invoked lambda

        long sleepMillis = TracingUtils::MakeCallWithTiming<long>(
            [&]() -> long {
                return m_clientConfig->retryStrategy->CalculateDelayBeforeNextRetry(outcome.GetError(), static_cast<long>(pRequestCtx->m_retryCount));
            },
            TracingUtils::SMITHY_CLIENT_SERVICE_BACKOFF_DELAY_METRIC,
            *m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
             {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        // Sleep only if neither clock skew nor region caused the failure. AdjustClockSkew self-gates on the disable knob.
        bool shouldSleep = !this->AdjustClockSkew(outcome, *pRequestCtx) && !retryWithCorrectRegion;
        pRequestCtx->m_attemptSkew = m_clientSkew->Load();

        if (!retryWithCorrectRegion && !m_clientConfig->retryStrategy->ShouldRetry(outcome.GetError(), static_cast<long>(pRequestCtx->m_retryCount)))
        {
            const bool blockedByQuotaOnly = outcome.GetError().ShouldRetry() &&
                static_cast<long>(pRequestCtx->m_retryCount) + 1 < m_clientConfig->retryStrategy->GetMaxAttempts();
            if (m_enableNewRetries && blockedByQuotaOnly && pRequestCtx->m_pRequest && pRequestCtx->m_pRequest->IsLongPollingOperation()) {
                giveUpDelay = std::chrono::milliseconds(sleepMillis);
            }
            break;
        }

        AWS_LOGSTREAM_WARN(AWS_SMITHY_CLIENT_LOG, "Request failed, now waiting " << sleepMillis << " ms before attempting again.");

        if(pRequestCtx->m_pRequest) {
          if (pRequestCtx->m_pRequest->GetBody()) {
            pRequestCtx->m_pRequest->GetBody()->clear();
            pRequestCtx->m_pRequest->GetBody()->seekg(0);
          }

          if (pRequestCtx->m_pRequest->GetRequestRetryHandler()) {
            pRequestCtx->m_pRequest->GetRequestRetryHandler()(*pRequestCtx->m_pRequest);
          }
        }

        if (retryWithCorrectRegion)
        {
            Aws::String newEndpoint = m_errorMarshaller->ExtractEndpoint(outcome.GetError());
            if (!newEndpoint.empty()) {
              Aws::Http::URI newUri = pRequestCtx->m_endpoint.GetURI();
              newUri.SetAuthority(newEndpoint);
              pRequestCtx->m_endpoint.SetURI(newUri);
              AWS_LOGSTREAM_DEBUG(AWS_SMITHY_CLIENT_LOG, "Endpoint has been updated to " << newUri.GetURIString());
            }
        }
        if (serverTime.WasParseSuccessful() && serverTime != Utils::DateTime())
        {
            pRequestCtx->m_requestInfo.ttl = Utils::DateTime::Now() + clockSkew + std::chrono::milliseconds(m_clientConfig->requestTimeoutMs);
        }
        pRequestCtx->m_requestInfo.attempt ++;
        pRequestCtx->m_requestInfo.maxAttempts = m_clientConfig->retryStrategy->GetMaxAttempts();

        Aws::Monitoring::OnRequestRetry(this->GetServiceClientName(), pRequestCtx->m_requestName, pRequestCtx->m_httpRequest, pRequestCtx->m_monitoringContexts);

        pRequestCtx->m_retryCount++;
        return {true, shouldSleep ? std::chrono::milliseconds(sleepMillis) : std::chrono::milliseconds(0)};
    } while(false); // end of goto in a form of "do { break; } while(false);"

    auto meter = m_clientConfig->telemetryProvider->getMeter(this->GetServiceClientName(), {});
    auto counter = meter->CreateCounter(TracingUtils::SMITHY_CLIENT_SERVICE_ATTEMPTS_METRIC, TracingUtils::COUNT_METRIC_TYPE, "");
    counter->add(pRequestCtx->m_requestInfo.attempt, {{TracingUtils::SMITHY_METHOD_DIMENSION, pRequestCtx->m_requestName},
                                                      {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    Aws::Monitoring::OnFinish(this->GetServiceClientName(), pRequestCtx->m_requestName, pRequestCtx->m_httpRequest, pRequestCtx->m_monitoringContexts);

    pRequestCtx->m_outcome = std::move(outcome);
    return {false, giveUpDelay};
}

AwsSmithyClientBase::HttpResponseOutcome
AwsSmithyClientBase::MakeRequestSync(Aws::AmazonWebServiceRequest const * const request,
                                     const char* requestName,
                                     Aws::Http::HttpMethod method,
                                     EndpointUpdateCallback&& endpointCallback,
                                     AuthResolvedCallback&& authCallback = nullptr) const
{
    std::shared_ptr<Aws::Utils::Threading::Executor> pExecutor = Aws::MakeShared<Aws::Utils::Threading::SameThreadExecutor>(AWS_SMITHY_CLIENT_LOG);
    assert(pExecutor);

    HttpResponseOutcome outcome = ClientError(CoreErrors::INTERNAL_FAILURE, "", "Response handler was not called", false);
    ResponseHandlerFunc responseHandler = [&outcome](HttpResponseOutcome&& asyncOutcome)
    {
        outcome = std::move(asyncOutcome);
    };

    pExecutor->Submit([&]()
    {
        if (const auto pRequestCtx = CreateRequestContext(request, requestName, method, std::move(endpointCallback), std::move(responseHandler), std::move(authCallback), pExecutor))
        {
            RunAttemptsBlocking(pRequestCtx);
        }
    });
    pExecutor->WaitUntilStopped();

    return outcome;
}

void AwsSmithyClientBase::DisableRequestProcessing()
{
    m_httpClient->DisableRequestProcessing();
}

void AwsSmithyClientBase::EnableRequestProcessing()
{
    m_httpClient->EnableRequestProcessing();
}

AwsSmithyClientBase::StreamOutcome AwsSmithyClientBase::MakeRequestWithUnparsedResponse(Aws::AmazonWebServiceRequest const * const request,
                                const char* requestName,
                                Aws::Http::HttpMethod method,
                                EndpointUpdateCallback&& endpointCallback
                                ) const
{
    if (const auto asyncOperationState = request ? Aws::Client::ProtocolAsyncOperationState<StreamOutcome>::Take(*request) : nullptr)
    {
        MakeRequestAsync(request, requestName, method, std::move(endpointCallback),
            [asyncOperationState](HttpResponseOutcome&& httpResponseOutcome)
            {
                asyncOperationState->Complete(ProcessUnparsedResponse(httpResponseOutcome));
            },
            nullptr, m_clientConfig->executor);
        return StreamOutcome(ClientError(CoreErrors::INTERNAL_FAILURE, "", "Request continues on the async request path", false));
    }

    auto httpResponseOutcome = MakeRequestSync(request, requestName, method, std::move(endpointCallback));
    return ProcessUnparsedResponse(httpResponseOutcome);
}

AwsSmithyClientBase::StreamOutcome AwsSmithyClientBase::ProcessUnparsedResponse(HttpResponseOutcome& httpResponseOutcome)
{
    if (httpResponseOutcome.IsSuccess())
    {
        return  StreamOutcome(Aws::AmazonWebServiceResult<Aws::Utils::Stream::ResponseStream>(
            httpResponseOutcome.GetResult()->SwapResponseStreamOwnership(),
            httpResponseOutcome.GetResult()->GetHeaders(), httpResponseOutcome.GetResult()->GetResponseCode()));
    }

    return StreamOutcome(std::move(httpResponseOutcome));
}

void AwsSmithyClientBase::AppendToUserAgent(const Aws::String& valueToAppend)
{
   assert(m_userAgentInterceptor);
   m_userAgentInterceptor->AddLegacyFeaturesToUserAgent(valueToAppend);
}

/*
    blocking API to resolve endpoint from request
*/
AwsSmithyClientBase::ResolveEndpointOutcome AwsSmithyClientBase::ResolveEndpointFromRequest(
    Aws::AmazonWebServiceRequest const * const request,
    const char* requestName,
    EndpointUpdateCallback&& endpointCallback) const
{
    ResolveEndpointOutcome outcome = ClientError(CoreErrors::INTERNAL_FAILURE, "", "Response handler was not called", false);
    ResponseHandlerFunc responseHandler = [&outcome](HttpResponseOutcome&& asyncOutcome)
    {
        outcome = std::move(asyncOutcome);
    };

    auto authResolver = request->GetRequestSpecificSupportedAuth().empty() ? nullptr : Aws::MakeShared<GenericAuthSchemeResolver<>>(AWS_SMITHY_CLIENT_LOG, request->GetRequestSpecificSupportedAuth());
    std::shared_ptr<AwsSmithyClientAsyncRequestContext> pRequestCtx = Aws::MakeShared<AwsSmithyClientAsyncRequestContext>(AWS_SMITHY_CLIENT_LOG, request, requestName, nullptr, authResolver);
    if (!pRequestCtx)
    {
        AWS_LOGSTREAM_ERROR(AWS_SMITHY_CLIENT_LOG, "Failed to allocate an AwsSmithyClientAsyncRequestContext under a shared ptr");
        auto result = HttpResponseOutcome(ClientError(CoreErrors::MEMORY_ALLOCATION, "", "Failed to allocate async request context", false/*retryable*/));
        responseHandler(std::move(result));
    }
    else
    {
        if(this->ResolveIdentityAuth(
            pRequestCtx, 
            std::move(responseHandler),                  
            std::move(endpointCallback)
        ))
        {
            outcome = std::move(pRequestCtx->m_endpoint);
        }
    }
    return outcome;
}