/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <smithy/tracing/TracingUtils.h>

using namespace smithy::components::tracing;


const char TracingUtils::COUNT_METRIC_TYPE[] = "Count";
const char TracingUtils::MICROSECOND_METRIC_TYPE[] = "Microseconds";
const char TracingUtils::BYTES_PER_SECOND_METRIC_TYPE[] = "Bytes/Second";
const char TracingUtils::SMITHY_CLIENT_DURATION_METRIC[] = "smithy.client.duration";
const char TracingUtils::SMITHY_CLIENT_ENDPOINT_RESOLUTION_METRIC[] = "smithy.client.resolve_endpoint_duration";
const char TracingUtils::SMITHY_CLIENT_DESERIALIZATION_METRIC[] = "smithy.client.deserialization_duration";
const char TracingUtils::SMITHY_CLIENT_SERIALIZATION_METRIC[] = "smithy.client.serialization_duration";
const char TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC[] = "smithy.client.service_call_duration";
const char TracingUtils::SMITHY_CLIENT_SIGNING_METRIC[] = "smithy.client.auth.signing_duration";
const char TracingUtils::SMITHY_CLIENT_SERVICE_BACKOFF_DELAY_METRIC[] = "smithy.client.backoff_delay";
const char TracingUtils::SMITHY_CLIENT_SERVICE_ATTEMPTS_METRIC[] = "smithy.client.attempts";
const char TracingUtils::SMITHY_METHOD_AWS_VALUE[] = "aws-api";
const char TracingUtils::SMITHY_SERVICE_DIMENSION[] = "rpc.service";
const char TracingUtils::SMITHY_METHOD_DIMENSION[] = "rpc.method";
const char TracingUtils::SMITHY_SYSTEM_DIMENSION[] = "rpc.system";
const char TracingUtils::SMITHY_METRICS_DNS_DURATION[] = "smithy.client.http.dns_duration";
const char TracingUtils::SMITHY_METRICS_CONNECT_DURATION[] = "smithy.client.http.connect_duration";
const char TracingUtils::SMITHY_METRICS_SSL_DURATION[] = "smithy.client.http.ssl_duration";
const char TracingUtils::SMITHY_METRICS_DOWNLOAD_SPEED_METRIC[] = "smithy.client.http.download_speed";
const char TracingUtils::SMITHY_METRICS_UPLOAD_SPEED_METRIC[] = "smithy.client.http.upload_speed";
const char TracingUtils::SMITHY_METRICS_UNKNOWN_METRIC[] = "smithy.client.http.unknown_metric";

void TracingUtils::RecordExecutionDuration(
    SteadyTime before,
    SteadyTime after,
    Aws::String metricName,
    const Meter &meter,
    Aws::Map<Aws::String, Aws::String> attributes,
    Aws::String description
) {
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(after - before).count();
    auto histogram = meter.CreateHistogram(std::move(metricName), MICROSECOND_METRIC_TYPE, description);
    if (!histogram) {
        AWS_LOG_ERROR("TracingUtil", "Failed to create histogram");
    } else {
        histogram->record((double) duration, std::move(attributes));
    }
}

TracingUtils::ScopedMetricTimer::ScopedMetricTimer(Aws::String metricName, std::shared_ptr<Meter> meter, Aws::Map<Aws::String, Aws::String> attributes)
    : m_start(std::chrono::steady_clock::now()),
      m_metricName(std::move(metricName)),
      m_meter(std::move(meter)),
      m_attributes(std::move(attributes))
{
}

TracingUtils::ScopedMetricTimer::~ScopedMetricTimer()
{
    if (m_meter) {
        RecordExecutionDuration(m_start, std::chrono::steady_clock::now(), m_metricName, *m_meter, m_attributes, "");
    }
}
