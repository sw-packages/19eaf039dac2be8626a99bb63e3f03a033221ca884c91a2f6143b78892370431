/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/core/client/AWSClient.h>
#include <aws/core/client/AsyncOperationState.h>
#include <aws/core/AmazonWebServiceRequest.h>
#include <aws/core/auth/AWSAuthSigner.h>
#include <aws/core/auth/AWSAuthSignerProvider.h>
#include <aws/core/client/AWSUrlPresigner.h>
#include <aws/core/client/AWSError.h>
#include <aws/core/client/AWSErrorMarshaller.h>
#include <aws/core/client/ClientConfiguration.h>
#include <aws/core/client/CoreErrors.h>
#include <aws/core/client/RetryStrategy.h>
#include <aws/core/client/RequestCompression.h>
#include <aws/core/http/HttpClient.h>
#include <aws/core/http/HttpClientFactory.h>
#include <aws/core/http/HttpResponse.h>
#include <aws/core/http/standard/StandardHttpResponse.h>
#include <aws/core/http/URI.h>
#include <aws/core/utils/stream/ResponseStream.h>
#include <aws/core/utils/json/JsonSerializer.h>
#include <aws/core/utils/Outcome.h>
#include <aws/core/utils/StringUtils.h>
#include <aws/core/utils/xml/XmlSerializer.h>
#include <aws/core/utils/memory/stl/AWSStringStream.h>
#include <aws/core/utils/logging/LogMacros.h>
#include <aws/core/Globals.h>
#include <aws/core/utils/EnumParseOverflowContainer.h>
#include <aws/core/internal/ClockSkew.h>
#include <aws/core/utils/crypto/MD5.h>
#include <aws/core/utils/crypto/CRC32.h>
#include <aws/core/utils/crypto/Sha256.h>
#include <aws/core/utils/crypto/Sha1.h>
#include <aws/core/utils/crypto/PrecalculatedHash.h>
#include <aws/core/utils/HashingUtils.h>
#include <aws/core/utils/crypto/Factories.h>
#include <aws/core/utils/event/EventStream.h>
#include <aws/core/utils/UUID.h>
#include <aws/core/monitoring/MonitoringManager.h>
#include <aws/core/utils/threading/Executor.h>
#include <aws/crt/Optional.h>
#include <aws/core/Region.h>
#include <aws/core/utils/DNS.h>
#include <aws/core/Version.h>
#include <aws/core/platform/Environment.h>
#include <aws/core/platform/OSVersionInfo.h>

#include <smithy/tracing/TracingUtils.h>
#include <smithy/client/features/ChecksumInterceptor.h>
#include <smithy/client/features/ChunkingInterceptor.h>

#include <cstring>
#include <cassert>
#include <iomanip>

using namespace Aws;
using namespace Aws::Client;
using namespace Aws::Http;
using namespace Aws::Utils;
using namespace Aws::Utils::Json;
using namespace Aws::Utils::Xml;
using namespace smithy::components::tracing;
using namespace smithy::interceptor;

static const int SUCCESS_RESPONSE_MIN = 200;
static const int SUCCESS_RESPONSE_MAX = 299;

static const char AWS_CLIENT_LOG_TAG[] = "AWSClient";
static const char AWS_LAMBDA_FUNCTION_NAME[] = "AWS_LAMBDA_FUNCTION_NAME";
static const char X_AMZN_TRACE_ID[] = "_X_AMZN_TRACE_ID";

CoreErrors AWSClient::GuessBodylessErrorType(Aws::Http::HttpResponseCode responseCode)
{
    switch (responseCode)
    {
    case HttpResponseCode::FORBIDDEN:
    case HttpResponseCode::UNAUTHORIZED:
        return CoreErrors::ACCESS_DENIED;
    case HttpResponseCode::NOT_FOUND:
        return CoreErrors::RESOURCE_NOT_FOUND;
    default:
        return CoreErrors::UNKNOWN;
    }
}

bool AWSClient::DoesResponseGenerateError(const std::shared_ptr<HttpResponse>& response)
{
    if (response->HasClientError()) return true;

    int responseCode = static_cast<int>(response->GetResponseCode());
    return responseCode < SUCCESS_RESPONSE_MIN || responseCode > SUCCESS_RESPONSE_MAX;
}

struct RequestInfo
{
    Aws::Utils::DateTime ttl;
    long attempt;
    long maxAttempts;

    operator String()
    {
        Aws::StringStream ss;
        if (ttl.WasParseSuccessful() && ttl != DateTime())
        {
            assert(attempt > 1);
            ss << "ttl=" << ttl.ToGmtString(DateFormat::ISO_8601_BASIC) << "; ";
        }
        ss << "attempt=" << attempt;
        if (maxAttempts > 0)
        {
            ss << "; max=" << maxAttempts;
        }
        return ss.str();
    }
};

namespace Aws
{
    namespace Client
    {
        struct AWSClientAsyncRequestContext
        {
            Aws::Http::URI uri;
            const Aws::AmazonWebServiceRequest* request = nullptr;
            Aws::Http::HttpMethod method = Aws::Http::HttpMethod::HTTP_GET;
            Aws::String signerName;
            Aws::Crt::Optional<Aws::String> signerRegion;
            Aws::Crt::Optional<Aws::String> signerServiceName;

            std::shared_ptr<Aws::Http::HttpRequest> httpRequest;
            HttpResponseOutcome outcome;
            AWSError<CoreErrors> lastError;
            Aws::Monitoring::CoreMetricsCollection coreMetrics;
            Aws::Vector<void*> monitoringContexts;
            Aws::String invocationId;
            RequestInfo requestInfo;
            std::shared_ptr<smithy::interceptor::InterceptorContext> interceptorContext;

            std::chrono::milliseconds attemptSkew{0};
            Aws::Utils::DateTime attemptSentTime;
            long retries = 0;

            HttpResponseOutcomeReceivedHandler handler;
            std::shared_ptr<Aws::Utils::Threading::Executor> executor;
            Aws::Crt::Optional<TracingUtils::ScopedMetricTimer> serviceCallTimer;
        };
    } // namespace Client
} // namespace Aws

AWSClient::AWSClient(const Aws::Client::ClientConfiguration& configuration,
    const std::shared_ptr<Aws::Client::AWSAuthSigner>& signer,
    const std::shared_ptr<AWSErrorMarshaller>& errorMarshaller) :
    m_region(configuration.region),
    m_telemetryProvider(configuration.telemetryProvider ? configuration.telemetryProvider : configuration.configFactories.telemetryProviderCreateFn()),
    m_signerProvider(Aws::MakeUnique<Aws::Auth::DefaultAuthSignerProvider>(AWS_CLIENT_LOG_TAG, signer)),
    m_httpClient(CreateHttpClient(
        [&configuration, this]()
        {
            ClientConfiguration tempConfig(configuration);
            tempConfig.telemetryProvider = m_telemetryProvider;
            return tempConfig;
        }())),
    m_errorMarshaller(errorMarshaller),
    m_retryStrategy(configuration.retryStrategy ? configuration.retryStrategy : configuration.configFactories.retryStrategyCreateFn()),
    m_writeRateLimiter(configuration.writeRateLimiter ? configuration.writeRateLimiter : configuration.configFactories.writeRateLimiterCreateFn()),
    m_readRateLimiter(configuration.readRateLimiter ? configuration.readRateLimiter : configuration.configFactories.readRateLimiterCreateFn()),
    m_hash(Aws::Utils::Crypto::CreateMD5Implementation()),
    m_requestTimeoutMs(configuration.requestTimeoutMs),
    m_enableClockSkewAdjustment(configuration.enableClockSkewAdjustment),
    m_clientSkew(Aws::MakeShared<Aws::Internal::ClientSkew>(AWS_CLIENT_LOG_TAG, std::chrono::milliseconds(0))),
    m_requestCompressionConfig(configuration.requestCompressionConfig),
    m_userAgentInterceptor{Aws::MakeShared<smithy::client::UserAgentInterceptor>(AWS_CLIENT_LOG_TAG, configuration, m_retryStrategy->GetStrategyName(), m_serviceName)},
    m_interceptors{Aws::MakeShared<smithy::client::ChecksumInterceptor>(AWS_CLIENT_LOG_TAG), Aws::MakeShared<smithy::client::features::ChunkingInterceptor>(AWS_CLIENT_LOG_TAG,
        m_httpClient->IsDefaultAwsHttpClient() ? Aws::Client::HttpClientChunkedMode::DEFAULT : configuration.httpClientChunkedMode,
        configuration.awsChunkedBufferSize),
        m_userAgentInterceptor},
    m_enableNewRetries{Aws::Utils::StringUtils::ToLower(Aws::Environment::GetEnv("AWS_NEW_RETRIES_2026").c_str()) == "true"},
    m_disableExpectHeader(configuration.disableExpectHeader)
{
}

AWSClient::AWSClient(const Aws::Client::ClientConfiguration& configuration,
    const std::shared_ptr<Aws::Auth::AWSAuthSignerProvider>& signerProvider,
    const std::shared_ptr<AWSErrorMarshaller>& errorMarshaller) :
    m_region(configuration.region),
    m_telemetryProvider(configuration.telemetryProvider ? configuration.telemetryProvider : configuration.configFactories.telemetryProviderCreateFn()),
    m_signerProvider(signerProvider),
    m_httpClient(CreateHttpClient(
        [&configuration, this]()
        {
            ClientConfiguration tempConfig(configuration);
            tempConfig.telemetryProvider = m_telemetryProvider;
            return tempConfig;
        }())),
    m_errorMarshaller(errorMarshaller),
    m_retryStrategy(configuration.retryStrategy ? configuration.retryStrategy : configuration.configFactories.retryStrategyCreateFn()),
    m_writeRateLimiter(configuration.writeRateLimiter ? configuration.writeRateLimiter : configuration.configFactories.writeRateLimiterCreateFn()),
    m_readRateLimiter(configuration.readRateLimiter ? configuration.readRateLimiter : configuration.configFactories.readRateLimiterCreateFn()),
    m_hash(Aws::Utils::Crypto::CreateMD5Implementation()),
    m_requestTimeoutMs(configuration.requestTimeoutMs),
    m_enableClockSkewAdjustment(configuration.enableClockSkewAdjustment),
    m_clientSkew(Aws::MakeShared<Aws::Internal::ClientSkew>(AWS_CLIENT_LOG_TAG, std::chrono::milliseconds(0))),
    m_requestCompressionConfig(configuration.requestCompressionConfig),
    m_userAgentInterceptor{Aws::MakeShared<smithy::client::UserAgentInterceptor>(AWS_CLIENT_LOG_TAG, configuration, m_retryStrategy->GetStrategyName(), m_serviceName)},
    m_interceptors{Aws::MakeShared<smithy::client::ChecksumInterceptor>(AWS_CLIENT_LOG_TAG, configuration), Aws::MakeShared<smithy::client::features::ChunkingInterceptor>(AWS_CLIENT_LOG_TAG,
        m_httpClient->IsDefaultAwsHttpClient() ? Aws::Client::HttpClientChunkedMode::DEFAULT : configuration.httpClientChunkedMode,
        configuration.awsChunkedBufferSize),
        m_userAgentInterceptor},
    m_enableNewRetries{Aws::Utils::StringUtils::ToLower(Aws::Environment::GetEnv("AWS_NEW_RETRIES_2026").c_str()) == "true"},
    m_disableExpectHeader(configuration.disableExpectHeader)
{
}

void AWSClient::DisableRequestProcessing()
{
    m_httpClient->DisableRequestProcessing();
}

void AWSClient::EnableRequestProcessing()
{
    m_httpClient->EnableRequestProcessing();
}

void AWSClient::SetServiceClientName(const Aws::String& name)
{
    m_serviceName = std::move(name);
    assert(m_userAgentInterceptor);
    m_userAgentInterceptor->SetApiName(m_serviceName);
}

void AWSClient::AppendToUserAgent(const Aws::String& valueToAppend)
{
   assert(m_userAgentInterceptor);
   m_userAgentInterceptor->AddLegacyFeaturesToUserAgent(valueToAppend);
}

Aws::Client::AWSAuthSigner* AWSClient::GetSignerByName(const char* name) const
{
    const auto& signer =  m_signerProvider->GetSigner(name);
    return signer ? signer.get() : nullptr;
}

static DateTime GetServerTimeFromError(const AWSError<CoreErrors> error)
{
    const Http::HeaderValueCollection& headers = error.GetResponseHeaders();
    auto awsDateHeaderIter = headers.find(StringUtils::ToLower(Http::AWS_DATE_HEADER));
    auto dateHeaderIter = headers.find(StringUtils::ToLower(Http::DATE_HEADER));
    if (awsDateHeaderIter != headers.end())
    {
        return DateTime(awsDateHeaderIter->second.c_str(), DateFormat::AutoDetect);
    }
    else if (dateHeaderIter != headers.end())
    {
        return DateTime(dateHeaderIter->second.c_str(), DateFormat::AutoDetect);
    }
    else
    {
        return DateTime();
    }
}

bool AWSClient::AdjustClockSkew(HttpResponseOutcome& outcome, const Aws::Utils::DateTime& timeRequestSent, const Aws::Utils::DateTime& timeResponseReceived, std::chrono::milliseconds attemptSkew) const
{
    if (m_enableClockSkewAdjustment)
    {
        const auto measurement = Aws::Internal::MakeClockSkewMeasurement(outcome.GetError().GetResponseHeaders(), timeRequestSent, timeResponseReceived);
        const auto adjustment = m_clientSkew->EvaluateFailure(measurement, attemptSkew);
        // Force a retry only when the error is a clock-skew error code and the skew exceeds the threshold.
        if (Aws::Internal::IsClockSkewError(outcome.GetError()) && adjustment.skewExceedsThreshold)
        {
            AWS_LOGSTREAM_WARN(AWS_CLIENT_LOG_TAG, "Signature check likely failed due to clock skew; adjusting the signing timestamp and retrying.");
            AWSError<CoreErrors> newError(
                outcome.GetError().GetErrorType(), outcome.GetError().GetExceptionName(), outcome.GetError().GetMessage(), true);
            newError.SetResponseHeaders(outcome.GetError().GetResponseHeaders());
            newError.SetResponseCode(outcome.GetError().GetResponseCode());
            outcome = std::move(newError);
            return true;
        }
    }
    return false;
}

HttpResponseOutcome AWSClient::AttemptExhaustively(const Aws::Http::URI& uri,
    const Aws::AmazonWebServiceRequest& request,
    Aws::Http::HttpMethod method,
    const char* signerName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    if (!Aws::Utils::IsValidHost(uri.GetHost()))
    {
        return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::VALIDATION, "", "Invalid DNS Label found in URI host", false/*retryable*/));
    }
    std::shared_ptr<HttpRequest> httpRequest(CreateHttpRequest(uri, method, request.GetResponseStreamFactory()));
    HttpResponseOutcome outcome;
    AWSError<CoreErrors> lastError;
    Aws::Monitoring::CoreMetricsCollection coreMetrics;
    auto contexts = Aws::Monitoring::OnRequestStarted(this->GetServiceClientName(), request.GetServiceRequestName(), httpRequest);
    const char* signerRegion = signerRegionOverride;
    Aws::String regionFromResponse;

    Aws::String invocationId = Aws::Utils::UUID::PseudoRandomUUID();
    RequestInfo requestInfo;
    requestInfo.attempt = 1;
    requestInfo.maxAttempts = m_enableNewRetries ? m_retryStrategy->GetMaxAttempts() : 0;
    httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, invocationId);
    httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, requestInfo);
    AppendRecursionDetectionHeader(httpRequest);

    // AttemptSkew: seeded from the client-level skew, updated after each attempt.
    std::chrono::milliseconds attemptSkew = m_clientSkew->Load();
    for (long retries = 0;; retries++)
    {
        if(!m_retryStrategy->HasSendToken())
        {
            return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::SLOW_DOWN,
                                                               "",
                                                               "Unable to acquire enough send tokens to execute request.",
                                                               false/*retryable*/));

        };
        httpRequest->SetEventStreamRequest(request.IsEventStreamRequest());
        httpRequest->SetHasEventStreamResponse(request.HasEventStreamResponse());

        const DateTime attemptSentTime = DateTime::Now();
        httpRequest->SetSigningTimestampOverride(attemptSentTime + attemptSkew);
        outcome = AttemptOneRequest(httpRequest, request, signerName, signerRegion, signerServiceNameOverride);
        const DateTime timeResponseReceived = DateTime::Now();
        outcome.SetRetryCount(retries);
        if (retries == 0)
        {
            m_retryStrategy->RequestBookkeeping(outcome);
        }
        else
        {
            m_retryStrategy->RequestBookkeeping(outcome, lastError);
        }
        coreMetrics.httpClientMetrics = httpRequest->GetRequestMetrics();
        TracingUtils::EmitCoreHttpMetrics(httpRequest->GetRequestMetrics(),
            *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},
             {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        if (outcome.IsSuccess())
        {
            if (m_enableClockSkewAdjustment && outcome.GetResult())
            {
                m_clientSkew->RecordResponse(Aws::Internal::MakeClockSkewMeasurement(outcome.GetResult()->GetHeaders(), attemptSentTime, timeResponseReceived));
            }
            Aws::Monitoring::OnRequestSucceeded(this->GetServiceClientName(), request.GetServiceRequestName(), httpRequest, outcome, coreMetrics, contexts);
            AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request successful returning.");
            break;
        }
        lastError = outcome.GetError();

        DateTime serverTime = GetServerTimeFromError(outcome.GetError());
        auto clockSkew = DateTime::Diff(serverTime, DateTime::Now());

        Aws::Monitoring::OnRequestFailed(this->GetServiceClientName(), request.GetServiceRequestName(), httpRequest, outcome, coreMetrics, contexts);

        if (!m_httpClient->IsRequestProcessingEnabled())
        {
            AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request was cancelled externally.");
            break;
        }

        // Adjust region
        bool retryWithCorrectRegion = false;
        HttpResponseCode httpResponseCode = outcome.GetError().GetResponseCode();
        if (httpResponseCode == HttpResponseCode::MOVED_PERMANENTLY ||  // 301
            httpResponseCode == HttpResponseCode::TEMPORARY_REDIRECT || // 307
            httpResponseCode == HttpResponseCode::BAD_REQUEST ||        // 400
            httpResponseCode == HttpResponseCode::FORBIDDEN)            // 403
        {
            regionFromResponse = GetErrorMarshaller()->ExtractRegion(outcome.GetError());
            if (m_region == Aws::Region::AWS_GLOBAL && !regionFromResponse.empty() && regionFromResponse != signerRegion)
            {
                signerRegion = regionFromResponse.c_str();
                retryWithCorrectRegion = true;
            }
        }

        long sleepMillis = TracingUtils::MakeCallWithTiming<long>(
            [&]() -> long {
                return m_retryStrategy->CalculateDelayBeforeNextRetry(outcome.GetError(), retries);
            },
            TracingUtils::SMITHY_CLIENT_SERVICE_BACKOFF_DELAY_METRIC,
            *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        //AdjustClockSkew returns true means clock skew was the problem and skew was adjusted, false otherwise.
        //sleep if clock skew and region was NOT the problem. AdjustClockSkew may update error inside outcome.
        bool shouldSleep = !AdjustClockSkew(outcome, attemptSentTime, timeResponseReceived, attemptSkew) && !retryWithCorrectRegion;
        attemptSkew = m_clientSkew->Load();

        if (!retryWithCorrectRegion && !m_retryStrategy->ShouldRetry(outcome.GetError(), retries))
        {
            const bool blockedByQuotaOnly = outcome.GetError().ShouldRetry() &&
                retries + 1 < m_retryStrategy->GetMaxAttempts();
            if (m_enableNewRetries && blockedByQuotaOnly && request.IsLongPollingOperation()) {
                m_httpClient->RetryRequestSleep(std::chrono::milliseconds(sleepMillis));
            }
            break;
        }
        if (request.IsEventStreamRequest() &&
             (request.GetBody()->eof() ||
             (outcome.GetError().GetResponseCode() != Http::HttpResponseCode::REQUEST_NOT_MADE &&
              outcome.GetError().GetResponseCode() != Http::HttpResponseCode::NETWORK_CONNECT_TIMEOUT &&
              outcome.GetError().GetResponseCode() != Http::HttpResponseCode::SERVICE_UNAVAILABLE))) {
          AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "SDK is not able to retry EventStream request after the connection was established");
          break;
        }

        AWS_LOGSTREAM_WARN(AWS_CLIENT_LOG_TAG, "Request failed, now waiting " << sleepMillis << " ms before attempting again.");
        if(request.GetBody())
        {
            if (request.GetBody()->tellg() == EOF) {
              // Save checksum information from the original request if we haven't already and stream is finalized
              RetryContext context = request.GetRetryContext();
              if (context.m_requestHash == nullptr) {
                auto originalRequestHash = httpRequest->GetRequestHash();
                if (originalRequestHash.second != nullptr) {
                  context.m_requestHash = Aws::MakeShared<std::pair<Aws::String, std::shared_ptr<Aws::Utils::Crypto::Hash>>>(AWS_CLIENT_LOG_TAG, originalRequestHash);
                  request.SetRetryContext(context);
                }
              }
            }
            request.GetBody()->clear();
            request.GetBody()->seekg(0);
        }

        if (request.GetRequestRetryHandler())
        {
            request.GetRequestRetryHandler()(request);
        }

        if (shouldSleep)
        {
            m_httpClient->RetryRequestSleep(std::chrono::milliseconds(sleepMillis));
        }

        Aws::Http::URI newUri = uri;
        Aws::String newEndpoint = GetErrorMarshaller()->ExtractEndpoint(outcome.GetError());
        if (!newEndpoint.empty())
        {
            newUri.SetAuthority(newEndpoint);
        }

        httpRequest = CreateHttpRequest(newUri, method, request.GetResponseStreamFactory());

        httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, invocationId);
        if (serverTime.WasParseSuccessful() && serverTime != DateTime())
        {
            requestInfo.ttl = DateTime::Now() + clockSkew + std::chrono::milliseconds(m_requestTimeoutMs);
        }
        requestInfo.attempt ++;
        requestInfo.maxAttempts = m_retryStrategy->GetMaxAttempts();
        httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, requestInfo);
        Aws::Monitoring::OnRequestRetry(this->GetServiceClientName(), request.GetServiceRequestName(), httpRequest, contexts);
    }
    auto meter = m_telemetryProvider->getMeter(this->GetServiceClientName(), {});
    auto counter = meter->CreateCounter(TracingUtils::SMITHY_CLIENT_SERVICE_ATTEMPTS_METRIC, TracingUtils::COUNT_METRIC_TYPE, "");
    counter->add(requestInfo.attempt, {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    Aws::Monitoring::OnFinish(this->GetServiceClientName(), request.GetServiceRequestName(), httpRequest, contexts);
    return outcome;
}

HttpResponseOutcome AWSClient::AttemptExhaustively(const Aws::Http::URI& uri,
    Aws::Http::HttpMethod method,
    const char* signerName,
    const char* requestName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    if (!Aws::Utils::IsValidHost(uri.GetHost()))
    {
        return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::VALIDATION, "", "Invalid DNS Label found in URI host", false/*retryable*/));
    }

    std::shared_ptr<HttpRequest> httpRequest(CreateHttpRequest(uri, method, Aws::Utils::Stream::DefaultResponseStreamFactoryMethod));
    HttpResponseOutcome outcome;
    AWSError<CoreErrors> lastError;
    Aws::Monitoring::CoreMetricsCollection coreMetrics;
    auto contexts = Aws::Monitoring::OnRequestStarted(this->GetServiceClientName(), requestName, httpRequest);
    const char* signerRegion = signerRegionOverride;
    Aws::String regionFromResponse;

    Aws::String invocationId = Aws::Utils::UUID::PseudoRandomUUID();
    RequestInfo requestInfo;
    requestInfo.attempt = 1;
    requestInfo.maxAttempts = m_enableNewRetries ? m_retryStrategy->GetMaxAttempts() : 0;
    httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, invocationId);
    httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, requestInfo);
    AppendRecursionDetectionHeader(httpRequest);

    // AttemptSkew: seeded from the client-level skew, updated after each attempt.
    std::chrono::milliseconds attemptSkew = m_clientSkew->Load();
    for (long retries = 0;; retries++)
    {
        if(!m_retryStrategy->HasSendToken())
        {
            return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::SLOW_DOWN,
                                                            "",
                                                            "Unable to acquire enough send tokens to execute request.",
                                                            false/*retryable*/));

        };
        const DateTime attemptSentTime = DateTime::Now();
        httpRequest->SetSigningTimestampOverride(attemptSentTime + attemptSkew);
        outcome = AttemptOneRequest(httpRequest, signerName, requestName, signerRegion, signerServiceNameOverride);
        const DateTime timeResponseReceived = DateTime::Now();
        outcome.SetRetryCount(retries);
        if (retries == 0)
        {
            m_retryStrategy->RequestBookkeeping(outcome);
        }
        else
        {
            m_retryStrategy->RequestBookkeeping(outcome, lastError);
        }
        coreMetrics.httpClientMetrics = httpRequest->GetRequestMetrics();
        TracingUtils::EmitCoreHttpMetrics(httpRequest->GetRequestMetrics(),
            *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, requestName},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        if (outcome.IsSuccess())
        {
            if (m_enableClockSkewAdjustment && outcome.GetResult())
            {
                m_clientSkew->RecordResponse(Aws::Internal::MakeClockSkewMeasurement(outcome.GetResult()->GetHeaders(), attemptSentTime, timeResponseReceived));
            }
            Aws::Monitoring::OnRequestSucceeded(this->GetServiceClientName(), requestName, httpRequest, outcome, coreMetrics, contexts);
            AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request successful returning.");
            break;
        }
        lastError = outcome.GetError();

        DateTime serverTime = GetServerTimeFromError(outcome.GetError());
        auto clockSkew = DateTime::Diff(serverTime, DateTime::Now());

        Aws::Monitoring::OnRequestFailed(this->GetServiceClientName(), requestName, httpRequest, outcome, coreMetrics, contexts);

        if (!m_httpClient->IsRequestProcessingEnabled())
        {
            AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request was cancelled externally.");
            break;
        }

        // Adjust region
        bool retryWithCorrectRegion = false;
        HttpResponseCode httpResponseCode = outcome.GetError().GetResponseCode();
        if (httpResponseCode == HttpResponseCode::MOVED_PERMANENTLY ||  // 301
            httpResponseCode == HttpResponseCode::TEMPORARY_REDIRECT || // 307
            httpResponseCode == HttpResponseCode::BAD_REQUEST ||        // 400
            httpResponseCode == HttpResponseCode::FORBIDDEN)            // 403
        {
            regionFromResponse = GetErrorMarshaller()->ExtractRegion(outcome.GetError());
            if (m_region == Aws::Region::AWS_GLOBAL && !regionFromResponse.empty() && regionFromResponse != signerRegion)
            {
                signerRegion = regionFromResponse.c_str();
                retryWithCorrectRegion = true;
            }
        }

        long sleepMillis = TracingUtils::MakeCallWithTiming<long>(
            [&]() -> long {
                return m_retryStrategy->CalculateDelayBeforeNextRetry(outcome.GetError(), retries);
            },
            TracingUtils::SMITHY_CLIENT_SERVICE_BACKOFF_DELAY_METRIC,
            *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
            {{TracingUtils::SMITHY_METHOD_DIMENSION, requestName},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
        //AdjustClockSkew returns true means clock skew was the problem and skew was adjusted, false otherwise.
        //sleep if clock skew and region was NOT the problem. AdjustClockSkew may update error inside outcome.
        bool shouldSleep = !AdjustClockSkew(outcome, attemptSentTime, timeResponseReceived, attemptSkew) && !retryWithCorrectRegion;
        attemptSkew = m_clientSkew->Load();

        if (!retryWithCorrectRegion && !m_retryStrategy->ShouldRetry(outcome.GetError(), retries))
        {
            break;
        }

        AWS_LOGSTREAM_WARN(AWS_CLIENT_LOG_TAG, "Request failed, now waiting " << sleepMillis << " ms before attempting again.");

        if (shouldSleep)
        {
            m_httpClient->RetryRequestSleep(std::chrono::milliseconds(sleepMillis));
        }

        Aws::Http::URI newUri = uri;
        Aws::String newEndpoint = GetErrorMarshaller()->ExtractEndpoint(outcome.GetError());
        if (!newEndpoint.empty())
        {
            newUri.SetAuthority(newEndpoint);
        }
        httpRequest = CreateHttpRequest(newUri, method, Aws::Utils::Stream::DefaultResponseStreamFactoryMethod);

        httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, invocationId);
        if (serverTime.WasParseSuccessful() && serverTime != DateTime())
        {
            requestInfo.ttl = DateTime::Now() + clockSkew + std::chrono::milliseconds(m_requestTimeoutMs);
        }
        requestInfo.attempt ++;
        requestInfo.maxAttempts = m_retryStrategy->GetMaxAttempts();
        httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, requestInfo);
        Aws::Monitoring::OnRequestRetry(this->GetServiceClientName(), requestName, httpRequest, contexts);
    }
    auto meter = m_telemetryProvider->getMeter(this->GetServiceClientName(), {});
    auto counter = meter->CreateCounter(TracingUtils::SMITHY_CLIENT_SERVICE_ATTEMPTS_METRIC, TracingUtils::COUNT_METRIC_TYPE, "");
    counter->add(requestInfo.attempt, {{TracingUtils::SMITHY_METHOD_DIMENSION, requestName},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    Aws::Monitoring::OnFinish(this->GetServiceClientName(), requestName, httpRequest, contexts);
    return outcome;
}

HttpResponseOutcome AWSClient::AttemptOneRequest(const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest, const Aws::AmazonWebServiceRequest& request,
    const char* signerName, const char* signerRegionOverride, const char* signerServiceNameOverride) const
{
    TracingUtils::MakeCallWithTiming(
        [&]() -> void {
            BuildHttpRequest(request, httpRequest);
        },
        TracingUtils::SMITHY_CLIENT_SERIALIZATION_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    InterceptorContext context{request};
    context.SetTransmitRequest(httpRequest);
    context.SetAttribute("signer_name", signerName);
    for (const auto& interceptor : m_interceptors)
    {
        const auto modifiedRequest = interceptor->ModifyBeforeSigning(context);
        if (!modifiedRequest.IsSuccess())
        {
            return modifiedRequest.GetError();
        }
    }

    auto signer = GetSignerByName(signerName);
    auto signedRequest = TracingUtils::MakeCallWithTiming<bool>([&]() -> bool {
            return signer->SignRequest(*httpRequest, signerRegionOverride, signerServiceNameOverride, true);
        },
        TracingUtils::SMITHY_CLIENT_SIGNING_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    if (!signedRequest)
    {
        AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "Request signing failed. Returning error.");
        return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::CLIENT_SIGNING_FAILURE, "", "SDK failed to sign the request", false/*retryable*/));
    }

    if (request.GetRequestSignedHandler())
    {
        request.GetRequestSignedHandler()(*httpRequest);
    }

    for (const auto& interceptor : m_interceptors) {
      const auto modifiedRequest = interceptor->ModifyBeforeTransmit(context);
      if (!modifiedRequest.IsSuccess()) {
        return modifiedRequest.GetError();
      }
    }

    AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request Successfully signed");
    auto httpResponse = TracingUtils::MakeCallWithTiming<std::shared_ptr<HttpResponse>>(
        [&]() -> std::shared_ptr<HttpResponse> {
            return m_httpClient->MakeRequest(httpRequest, m_readRateLimiter.get(), m_writeRateLimiter.get());
        },
        TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    if (DoesResponseGenerateError(httpResponse) )
    {
        AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request returned error. Attempting to generate appropriate error codes from response");
        auto error = BuildAWSError(httpResponse);
        return HttpResponseOutcome(std::move(error));
    }
    else if(request.HasEmbeddedError(httpResponse->GetResponseBody(), httpResponse->GetHeaders()))
    {
        AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Response has embedded errors");

        auto error = GetErrorMarshaller()->Marshall(*httpResponse);
        return HttpResponseOutcome(std::move(error) );
    }

    context.SetTransmitResponse(httpResponse);
    for (const auto& interceptor : m_interceptors) {
      const auto modifiedRequest = interceptor->ModifyBeforeDeserialization(context);
      if (!modifiedRequest.IsSuccess()) {
        return modifiedRequest.GetError();
      }
    }

    AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request returned successful response.");

    return HttpResponseOutcome(std::move(httpResponse));
}

HttpResponseOutcome AWSClient::AttemptOneRequest(const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest,
    const char* signerName, const char* requestName, const char* signerRegionOverride, const char* signerServiceNameOverride) const
{
    AWS_UNREFERENCED_PARAM(requestName);

    auto signer = GetSignerByName(signerName);
    auto signedRequest = ::TracingUtils::MakeCallWithTiming<bool>([&]() -> bool {
            return signer->SignRequest(*httpRequest, signerRegionOverride, signerServiceNameOverride, true);
        },
        TracingUtils::SMITHY_CLIENT_SIGNING_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, requestName},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    if (!signedRequest)
    {
        AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "Request signing failed. Returning error.");
        return HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::CLIENT_SIGNING_FAILURE, "", "SDK failed to sign the request", false/*retryable*/));
    }

    AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request Successfully signed");
    auto httpResponse = ::TracingUtils::MakeCallWithTiming<std::shared_ptr<HttpResponse>>(
        [&]() -> std::shared_ptr<HttpResponse> {
            return m_httpClient->MakeRequest(httpRequest, m_readRateLimiter.get(), m_writeRateLimiter.get());
        },
        TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, requestName},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    if (DoesResponseGenerateError(httpResponse))
    {
        AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request returned error. Attempting to generate appropriate error codes from response");
        auto error = BuildAWSError(httpResponse);
        return HttpResponseOutcome(std::move(error));
    }

    AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request returned successful response.");

    return HttpResponseOutcome(std::move(httpResponse));
}

void AWSClient::AttemptExhaustivelyAsync(const Aws::Http::URI& uri,
    const Aws::AmazonWebServiceRequest& request,
    Http::HttpMethod method,
    const char* signerName,
    HttpResponseOutcomeReceivedHandler handler,
    const std::shared_ptr<Aws::Utils::Threading::Executor>& executor,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    if (!Aws::Utils::IsValidHost(uri.GetHost()))
    {
        handler(HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::VALIDATION, "", "Invalid DNS Label found in URI host", false/*retryable*/)));
        return;
    }

    auto context = Aws::MakeShared<AWSClientAsyncRequestContext>(AWS_CLIENT_LOG_TAG);
    context->uri = uri;
    context->request = &request;
    context->method = method;
    context->signerName = signerName ? signerName : "";
    if (signerRegionOverride)
    {
        context->signerRegion = signerRegionOverride;
    }
    if (signerServiceNameOverride)
    {
        context->signerServiceName = signerServiceNameOverride;
    }
    context->handler = std::move(handler);
    context->executor = executor;
    context->invocationId = Aws::Utils::UUID::PseudoRandomUUID();

    context->httpRequest = CreateHttpRequest(uri, method, request.GetResponseStreamFactory());
    context->monitoringContexts = Aws::Monitoring::OnRequestStarted(this->GetServiceClientName(), request.GetServiceRequestName(), context->httpRequest);
    context->attemptSkew = m_clientSkew->Load();
    context->requestInfo.attempt = 1;
    context->requestInfo.maxAttempts = m_enableNewRetries ? m_retryStrategy->GetMaxAttempts() : 0;
    context->httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, context->invocationId);
    context->httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, context->requestInfo);
    AppendRecursionDetectionHeader(context->httpRequest);

    const AWSClient* self = this;
    auto prepareAttempt = [self, context]() -> std::shared_ptr<Aws::Http::HttpRequest>
    {
        return self->StartOneAttemptAsync(context);
    };
    auto evaluateAttempt = [self, context](std::shared_ptr<HttpResponse> httpResponse) -> Http::HttpClient::AttemptOutcome
    {
        return self->OnResponseReceivedAsync(context, std::move(httpResponse));
    };
    auto onComplete = [self, context]()
    {
        self->FinishAsync(context);
    };

    context->outcome = HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::USER_CANCELLED, "", "Request cancelled before completion", false/*retryable*/));

    auto error = m_httpClient->MakeRequestAsync(prepareAttempt, evaluateAttempt, onComplete, context->executor);
    if (error.has_value())
    {
        context->outcome = HttpResponseOutcome(*error);
        FinishAsync(context);
    }
}

std::shared_ptr<Aws::Http::HttpRequest> AWSClient::StartOneAttemptAsync(const std::shared_ptr<AWSClientAsyncRequestContext>& context) const
{
    const Aws::AmazonWebServiceRequest& request = *context->request;

    if (!m_retryStrategy->HasSendToken())
    {
        context->outcome = HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::SLOW_DOWN, "", "Unable to acquire enough send tokens to execute request.", false/*retryable*/));
        return nullptr;
    }

    context->httpRequest->SetEventStreamRequest(request.IsEventStreamRequest());
    context->httpRequest->SetHasEventStreamResponse(request.HasEventStreamResponse());

    context->attemptSentTime = DateTime::Now();
    context->httpRequest->SetSigningTimestampOverride(context->attemptSentTime + context->attemptSkew);

    const char* signerRegion = context->signerRegion ? context->signerRegion->c_str() : nullptr;
    const char* signerServiceName = context->signerServiceName ? context->signerServiceName->c_str() : nullptr;

    TracingUtils::MakeCallWithTiming(
        [&]() -> void {
            BuildHttpRequest(request, context->httpRequest);
        },
        TracingUtils::SMITHY_CLIENT_SERIALIZATION_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    context->interceptorContext = Aws::MakeShared<InterceptorContext>(AWS_CLIENT_LOG_TAG, request);
    context->interceptorContext->SetTransmitRequest(context->httpRequest);
    context->interceptorContext->SetAttribute("signer_name", context->signerName.c_str());
    for (const auto& interceptor : m_interceptors)
    {
        const auto modifiedRequest = interceptor->ModifyBeforeSigning(*context->interceptorContext);
        if (!modifiedRequest.IsSuccess())
        {
            context->outcome = HttpResponseOutcome(modifiedRequest.GetError());
            return nullptr;
        }
    }

    auto signer = GetSignerByName(context->signerName.c_str());
    const bool signedRequest = TracingUtils::MakeCallWithTiming<bool>([&]() -> bool {
            return signer->SignRequest(*context->httpRequest, signerRegion, signerServiceName, true);
        },
        TracingUtils::SMITHY_CLIENT_SIGNING_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    if (!signedRequest)
    {
        AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "Request signing failed. Returning error.");
        context->outcome = HttpResponseOutcome(AWSError<CoreErrors>(CoreErrors::CLIENT_SIGNING_FAILURE, "", "SDK failed to sign the request", false/*retryable*/));
        return nullptr;
    }

    if (request.GetRequestSignedHandler())
    {
        request.GetRequestSignedHandler()(*context->httpRequest);
    }

    for (const auto& interceptor : m_interceptors)
    {
        const auto modifiedRequest = interceptor->ModifyBeforeTransmit(*context->interceptorContext);
        if (!modifiedRequest.IsSuccess())
        {
            context->outcome = HttpResponseOutcome(modifiedRequest.GetError());
            return nullptr;
        }
    }

    context->serviceCallTimer.emplace(TracingUtils::SMITHY_CLIENT_SERVICE_CALL_METRIC,
        m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        Aws::Map<Aws::String, Aws::String>{
            {TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},
            {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    return context->httpRequest;
}

Http::HttpClient::AttemptOutcome AWSClient::OnResponseReceivedAsync(const std::shared_ptr<AWSClientAsyncRequestContext>& context, std::shared_ptr<HttpResponse> httpResponse) const
{
    const Aws::AmazonWebServiceRequest& request = *context->request;

    context->serviceCallTimer.reset();

    if (DoesResponseGenerateError(httpResponse))
    {
        AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Request returned error. Attempting to generate appropriate error codes from response");
        return OnAttemptCompleteAsync(context, HttpResponseOutcome(BuildAWSError(httpResponse)));
    }

    if (request.HasEmbeddedError(httpResponse->GetResponseBody(), httpResponse->GetHeaders()))
    {
        AWS_LOGSTREAM_DEBUG(AWS_CLIENT_LOG_TAG, "Response has embedded errors");
        return OnAttemptCompleteAsync(context, HttpResponseOutcome(GetErrorMarshaller()->Marshall(*httpResponse)));
    }

    context->interceptorContext->SetTransmitResponse(httpResponse);
    for (const auto& interceptor : m_interceptors)
    {
        const auto modifiedRequest = interceptor->ModifyBeforeDeserialization(*context->interceptorContext);
        if (!modifiedRequest.IsSuccess())
        {
            return OnAttemptCompleteAsync(context, HttpResponseOutcome(modifiedRequest.GetError()));
        }
    }

    return OnAttemptCompleteAsync(context, HttpResponseOutcome(std::move(httpResponse)));
}

Http::HttpClient::AttemptOutcome AWSClient::OnAttemptCompleteAsync(const std::shared_ptr<AWSClientAsyncRequestContext>& context, HttpResponseOutcome&& outcomeParam) const
{
    const Aws::AmazonWebServiceRequest& request = *context->request;
    HttpResponseOutcome outcome = std::move(outcomeParam);

    const DateTime timeResponseReceived = DateTime::Now();
    outcome.SetRetryCount(context->retries);
    if (context->retries == 0)
    {
        m_retryStrategy->RequestBookkeeping(outcome);
    }
    else
    {
        m_retryStrategy->RequestBookkeeping(outcome, context->lastError);
    }

    context->coreMetrics.httpClientMetrics = context->httpRequest->GetRequestMetrics();
    TracingUtils::EmitCoreHttpMetrics(context->httpRequest->GetRequestMetrics(),
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},
         {TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});

    if (outcome.IsSuccess())
    {
        if (m_enableClockSkewAdjustment && outcome.GetResult())
        {
            m_clientSkew->RecordResponse(Aws::Internal::MakeClockSkewMeasurement(outcome.GetResult()->GetHeaders(), context->attemptSentTime, timeResponseReceived));
        }
        Aws::Monitoring::OnRequestSucceeded(this->GetServiceClientName(), request.GetServiceRequestName(), context->httpRequest, outcome, context->coreMetrics, context->monitoringContexts);
        AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request successful returning.");
        context->outcome = std::move(outcome);
        return {};
    }

    context->lastError = outcome.GetError();

    DateTime serverTime = GetServerTimeFromError(outcome.GetError());
    auto clockSkew = DateTime::Diff(serverTime, DateTime::Now());

    Aws::Monitoring::OnRequestFailed(this->GetServiceClientName(), request.GetServiceRequestName(), context->httpRequest, outcome, context->coreMetrics, context->monitoringContexts);

    if (!m_httpClient->IsRequestProcessingEnabled())
    {
        AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Request was cancelled externally.");
        context->outcome = std::move(outcome);
        return {};
    }

    bool retryWithCorrectRegion = false;
    HttpResponseCode httpResponseCode = outcome.GetError().GetResponseCode();
    if (httpResponseCode == HttpResponseCode::MOVED_PERMANENTLY ||
        httpResponseCode == HttpResponseCode::TEMPORARY_REDIRECT ||
        httpResponseCode == HttpResponseCode::BAD_REQUEST ||
        httpResponseCode == HttpResponseCode::FORBIDDEN)
    {
        Aws::String regionFromResponse = GetErrorMarshaller()->ExtractRegion(outcome.GetError());
        Aws::String currentSignerRegion = context->signerRegion ? *context->signerRegion : Aws::String();
        if (m_region == Aws::Region::AWS_GLOBAL && !regionFromResponse.empty() && regionFromResponse != currentSignerRegion)
        {
            context->signerRegion = regionFromResponse;
            retryWithCorrectRegion = true;
        }
    }

    long sleepMillis = TracingUtils::MakeCallWithTiming<long>(
        [&]() -> long {
            return m_retryStrategy->CalculateDelayBeforeNextRetry(outcome.GetError(), context->retries);
        },
        TracingUtils::SMITHY_CLIENT_SERVICE_BACKOFF_DELAY_METRIC,
        *m_telemetryProvider->getMeter(this->GetServiceClientName(), {}),
        {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    bool shouldSleep = !AdjustClockSkew(outcome, context->attemptSentTime, timeResponseReceived, context->attemptSkew) && !retryWithCorrectRegion;
    context->attemptSkew = m_clientSkew->Load();

    if (!retryWithCorrectRegion && !m_retryStrategy->ShouldRetry(outcome.GetError(), context->retries))
    {
        const bool blockedByQuotaOnly = outcome.GetError().ShouldRetry() &&
            context->retries + 1 < m_retryStrategy->GetMaxAttempts();
        context->outcome = std::move(outcome);
        if (m_enableNewRetries && blockedByQuotaOnly && request.IsLongPollingOperation()) {
            return {false, std::chrono::milliseconds(sleepMillis)};
        }
        return {};
    }

    if (request.IsEventStreamRequest() &&
         (request.GetBody()->eof() ||
         (outcome.GetError().GetResponseCode() != Http::HttpResponseCode::REQUEST_NOT_MADE &&
          outcome.GetError().GetResponseCode() != Http::HttpResponseCode::NETWORK_CONNECT_TIMEOUT &&
          outcome.GetError().GetResponseCode() != Http::HttpResponseCode::SERVICE_UNAVAILABLE)))
    {
        AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "SDK is not able to retry EventStream request after the connection was established");
        context->outcome = std::move(outcome);
        return {};
    }

    AWS_LOGSTREAM_WARN(AWS_CLIENT_LOG_TAG, "Request failed, now waiting " << sleepMillis << " ms before attempting again.");
    if (request.GetBody())
    {
        if (request.GetBody()->tellg() == EOF)
        {
            RetryContext retryContext = request.GetRetryContext();
            if (retryContext.m_requestHash == nullptr)
            {
                auto originalRequestHash = context->httpRequest->GetRequestHash();
                if (originalRequestHash.second != nullptr)
                {
                    retryContext.m_requestHash = Aws::MakeShared<std::pair<Aws::String, std::shared_ptr<Aws::Utils::Crypto::Hash>>>(AWS_CLIENT_LOG_TAG, originalRequestHash);
                    request.SetRetryContext(retryContext);
                }
            }
        }
        request.GetBody()->clear();
        request.GetBody()->seekg(0);
    }

    if (request.GetRequestRetryHandler())
    {
        request.GetRequestRetryHandler()(request);
    }

    Aws::Http::URI newUri = context->uri;
    Aws::String newEndpoint = GetErrorMarshaller()->ExtractEndpoint(outcome.GetError());
    if (!newEndpoint.empty())
    {
        newUri.SetAuthority(newEndpoint);
    }
    context->httpRequest = CreateHttpRequest(newUri, context->method, request.GetResponseStreamFactory());
    context->httpRequest->SetHeaderValue(Http::SDK_INVOCATION_ID_HEADER, context->invocationId);
    if (serverTime.WasParseSuccessful() && serverTime != DateTime())
    {
        context->requestInfo.ttl = DateTime::Now() + clockSkew + std::chrono::milliseconds(m_requestTimeoutMs);
    }
    context->requestInfo.attempt++;
    context->requestInfo.maxAttempts = m_retryStrategy->GetMaxAttempts();
    context->httpRequest->SetHeaderValue(Http::SDK_REQUEST_HEADER, context->requestInfo);
    Aws::Monitoring::OnRequestRetry(this->GetServiceClientName(), request.GetServiceRequestName(), context->httpRequest, context->monitoringContexts);

    context->retries++;
    return {true, shouldSleep ? std::chrono::milliseconds(sleepMillis) : std::chrono::milliseconds(0)};
}

void AWSClient::FinishAsync(const std::shared_ptr<AWSClientAsyncRequestContext>& context) const
{
    const Aws::AmazonWebServiceRequest& request = *context->request;
    auto meter = m_telemetryProvider->getMeter(this->GetServiceClientName(), {});
    auto counter = meter->CreateCounter(TracingUtils::SMITHY_CLIENT_SERVICE_ATTEMPTS_METRIC, TracingUtils::COUNT_METRIC_TYPE, "");
    counter->add(context->requestInfo.attempt, {{TracingUtils::SMITHY_METHOD_DIMENSION, request.GetServiceRequestName()},{TracingUtils::SMITHY_SERVICE_DIMENSION, this->GetServiceClientName()}});
    Aws::Monitoring::OnFinish(this->GetServiceClientName(), request.GetServiceRequestName(), context->httpRequest, context->monitoringContexts);
    if (context->handler)
    {
        context->handler(std::move(context->outcome));
    }
}

StreamOutcome AWSClient::MakeRequestWithUnparsedResponse(const Aws::Http::URI& uri,
    const Aws::AmazonWebServiceRequest& request,
    Http::HttpMethod method,
    const char* signerName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    if (const auto asyncOperationState = ProtocolAsyncOperationState<StreamOutcome>::Take(request))
    {
        AttemptExhaustivelyAsync(uri, request, method, signerName,
            [asyncOperationState](HttpResponseOutcome&& httpResponseOutcome)
            {
                asyncOperationState->Complete(ProcessUnparsedResponse(httpResponseOutcome));
            },
            asyncOperationState->GetExecutor(), signerRegionOverride, signerServiceNameOverride);
        return StreamOutcome(AWSError<CoreErrors>(CoreErrors::INTERNAL_FAILURE, "", "Request continues on the async request path", false));
    }

    HttpResponseOutcome httpResponseOutcome = AttemptExhaustively(uri, request, method, signerName, signerRegionOverride, signerServiceNameOverride);
    return ProcessUnparsedResponse(httpResponseOutcome);
}

StreamOutcome AWSClient::ProcessUnparsedResponse(HttpResponseOutcome& httpResponseOutcome)
{
    if (httpResponseOutcome.IsSuccess())
    {
        return StreamOutcome(AmazonWebServiceResult<Stream::ResponseStream>(
            httpResponseOutcome.GetResult()->SwapResponseStreamOwnership(),
            httpResponseOutcome.GetResult()->GetHeaders(), httpResponseOutcome.GetResult()->GetResponseCode()));
    }

    return StreamOutcome(std::move(httpResponseOutcome));
}

StreamOutcome AWSClient::MakeRequestWithUnparsedResponse(const Aws::Http::URI& uri,
    Http::HttpMethod method,
    const char* signerName,
    const char* requestName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    HttpResponseOutcome httpResponseOutcome = AttemptExhaustively(uri, method, signerName, requestName, signerRegionOverride, signerServiceNameOverride);
    if (httpResponseOutcome.IsSuccess())
    {
        return StreamOutcome(AmazonWebServiceResult<Stream::ResponseStream>(
            httpResponseOutcome.GetResult()->SwapResponseStreamOwnership(),
            httpResponseOutcome.GetResult()->GetHeaders(), httpResponseOutcome.GetResult()->GetResponseCode()));
    }

    return StreamOutcome(std::move(httpResponseOutcome));
}

StreamOutcome AWSClient::MakeRequestWithUnparsedResponse(const Aws::AmazonWebServiceRequest& request,
                                                         const Aws::Endpoint::AWSEndpoint& endpoint,
                                                         Http::HttpMethod method,
                                                         const char* signerName,
                                                         const char* signerRegionOverride,
                                                         const char* signerServiceNameOverride) const
{
    const Aws::Http::URI& uri = endpoint.GetURI();
    if (endpoint.GetAttributes()) {
        signerName = endpoint.GetAttributes()->authScheme.GetName().c_str();
        if (endpoint.GetAttributes()->authScheme.GetSigningRegion()) {
            signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegion()->c_str();
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningRegionSet()) {
            signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegionSet()->c_str();
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningName()) {
            signerServiceNameOverride = endpoint.GetAttributes()->authScheme.GetSigningName()->c_str();
        }
    }

    return MakeRequestWithUnparsedResponse(uri, request, method, signerName, signerRegionOverride, signerServiceNameOverride);
}

XmlOutcome AWSXMLClient::MakeRequestWithEventStream(const Aws::AmazonWebServiceRequest& request,
                                                    const Aws::Endpoint::AWSEndpoint& endpoint,
                                                    Http::HttpMethod method,
                                                    const char* signerName,
                                                    const char* signerRegionOverride,
                                                    const char* signerServiceNameOverride) const
{
    const Aws::Http::URI& uri = endpoint.GetURI();
    if (endpoint.GetAttributes()) {
        signerName = endpoint.GetAttributes()->authScheme.GetName().c_str();
        if (endpoint.GetAttributes()->authScheme.GetSigningRegion()) {
            signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegion()->c_str();
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningRegionSet()) {
            signerRegionOverride = endpoint.GetAttributes()->authScheme.GetSigningRegionSet()->c_str();
        }
        if (endpoint.GetAttributes()->authScheme.GetSigningName()) {
            signerServiceNameOverride = endpoint.GetAttributes()->authScheme.GetSigningName()->c_str();
        }
    }

    return MakeRequestWithEventStream(uri, request, method, signerName, signerRegionOverride, signerServiceNameOverride);
}

XmlOutcome AWSXMLClient::MakeRequestWithEventStream(const Aws::Http::URI& uri,
    const Aws::AmazonWebServiceRequest& request,
    Http::HttpMethod method,
    const char* signerName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    if (const auto asyncOperationState = ProtocolAsyncOperationState<XmlOutcome>::Take(request))
    {
        asyncOperationState->ExtendRequestLifetime();
        AttemptExhaustivelyAsync(uri, request, method, signerName,
            [asyncOperationState](HttpResponseOutcome&& httpOutcome)
            {
                if (httpOutcome.IsSuccess())
                {
                    asyncOperationState->Complete(XmlOutcome(AmazonWebServiceResult<XmlDocument>(XmlDocument(), httpOutcome.GetResult()->GetHeaders())));
                    return;
                }
                asyncOperationState->Complete(XmlOutcome(std::move(httpOutcome)));
            },
            asyncOperationState->GetExecutor(), signerRegionOverride, signerServiceNameOverride);
        return XmlOutcome(AWSError<CoreErrors>(CoreErrors::INTERNAL_FAILURE, "", "Request continues on the async request path", false));
    }

    HttpResponseOutcome httpOutcome = AttemptExhaustively(uri, request, method, signerName, signerRegionOverride, signerServiceNameOverride);
    if (httpOutcome.IsSuccess())
    {
        return XmlOutcome(AmazonWebServiceResult<XmlDocument>(XmlDocument(), httpOutcome.GetResult()->GetHeaders()));
    }

    return XmlOutcome(std::move(httpOutcome));
}

XmlOutcome AWSXMLClient::MakeRequestWithEventStream(const Aws::Http::URI& uri,
    Http::HttpMethod method,
    const char* signerName,
    const char* requestName,
    const char* signerRegionOverride,
    const char* signerServiceNameOverride) const
{
    HttpResponseOutcome httpOutcome = AttemptExhaustively(uri, method, signerName, requestName, signerRegionOverride, signerServiceNameOverride);
    if (httpOutcome.IsSuccess())
    {
        return XmlOutcome(AmazonWebServiceResult<XmlDocument>(XmlDocument(), httpOutcome.GetResult()->GetHeaders()));
    }

    return XmlOutcome(std::move(httpOutcome));
}

void AWSClient::AddHeadersToRequest(const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest,
    const Http::HeaderValueCollection& headerValues) const
{
    for (auto const& headerValue : headerValues)
    {
        httpRequest->SetHeaderValue(headerValue.first, headerValue.second);
    }
}

void AWSClient::AppendHeaderValueToRequest(const std::shared_ptr<Aws::Http::HttpRequest> &httpRequest, const String header, const String value) const
{
    if (!httpRequest->HasHeader(header.c_str()))
    {
        httpRequest->SetHeaderValue(header, value);
    }
    else
    {
        Aws::String contentEncoding = httpRequest->GetHeaderValue(header.c_str());
        contentEncoding.append(",").append(value);
        httpRequest->SetHeaderValue(header, contentEncoding);
    }
}

void AWSClient::AddContentBodyToRequest(const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest,
    const std::shared_ptr<Aws::IOStream>& body, bool needsContentMd5, bool isChunked) const
{
    httpRequest->AddContentBody(body);

    //If there is no body, we have a content length of 0
    //note: we also used to remove content-type, but S3 actually needs content-type on InitiateMultipartUpload and it isn't
    //forbidden by the spec. If we start getting weird errors related to this, make sure it isn't caused by this removal.
    if (!body)
    {
        AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "No content body, content-length headers");

        if(httpRequest->GetMethod() == HttpMethod::HTTP_POST || httpRequest->GetMethod() == HttpMethod::HTTP_PUT)
        {
            httpRequest->SetHeaderValue(Http::CONTENT_LENGTH_HEADER, "0");
        }
        else
        {
            httpRequest->DeleteHeader(Http::CONTENT_LENGTH_HEADER);
        }
    }
    AddContentLengthToRequest(httpRequest, body, isChunked);
    if (needsContentMd5 && body && !httpRequest->HasHeader(Http::CONTENT_MD5_HEADER))
    {
        AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Found body, and content-md5 needs to be set" <<
            ", attempting to compute content-md5");

        //changing the internal state of the hash computation is not a logical state
        //change as far as constness goes for this class. Due to the platform specificness
        //of hash computations, we can't control the fact that computing a hash mutates
        //state on some platforms such as windows (but that isn't a concern of this class.
        auto md5HashResult = const_cast<AWSClient*>(this)->m_hash->Calculate(*body);
        body->clear();
        if (md5HashResult.IsSuccess())
        {
            httpRequest->SetHeaderValue(Http::CONTENT_MD5_HEADER, HashingUtils::Base64Encode(md5HashResult.GetResult()));
        }
    }
}

void AWSClient::AddContentLengthToRequest(
  const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest,
  const std::shared_ptr<Aws::IOStream>& body,
  bool isChunked) const
{
  if (body && isChunked && !httpRequest->HasHeader(Http::CONTENT_LENGTH_HEADER)) {
    httpRequest->SetTransferEncoding(CHUNKED_VALUE);
  } else if (body && !httpRequest->HasHeader(Http::CONTENT_LENGTH_HEADER)) {
    if (!m_httpClient->SupportsChunkedTransferEncoding()) {
      AWS_LOGSTREAM_WARN(AWS_CLIENT_LOG_TAG, "This http client doesn't support transfer-encoding:chunked. " <<
                                             "The request may fail if it's not a seekable stream.");
    }
    AWS_LOGSTREAM_TRACE(AWS_CLIENT_LOG_TAG, "Found body, but content-length has not been set, attempting to compute content-length");
    body->seekg(0, body->end);
    auto streamSize = body->tellg();
    body->seekg(0, body->beg);
    Aws::StringStream ss;
    ss << streamSize;
    httpRequest->SetContentLength(ss.str());
  }
}

Aws::String Aws::Client::GetAuthorizationHeader(const Aws::Http::HttpRequest& httpRequest)
{
    // Extract the hex-encoded signature from the authorization header rather than recalculating it.
    assert(httpRequest.HasAwsAuthorization());
    const auto& authHeader = httpRequest.GetAwsAuthorization();
    auto signaturePosition = authHeader.rfind(Aws::Auth::SIGNATURE);
    // The auth header should end with 'Signature=<64 chars>'
    // Make sure we found the word 'Signature' in the header and make sure it's the last item followed by its 64 hex chars
    if (signaturePosition == Aws::String::npos || (signaturePosition + strlen(Aws::Auth::SIGNATURE) + 1/*'=' character*/ + 64/*hex chars*/) != authHeader.length())
    {
        AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "Failed to extract signature from authorization header.");
        return {};
    }
    return authHeader.substr(signaturePosition + strlen(Aws::Auth::SIGNATURE) + 1);
}

void AWSClient::BuildHttpRequest(const Aws::AmazonWebServiceRequest& request, const std::shared_ptr<Aws::Http::HttpRequest>& httpRequest) const
{
    //do headers first since the request likely will set content-length as its own header.
    AddHeadersToRequest(httpRequest, request.GetHeaders());
    AddHeadersToRequest(httpRequest, request.GetAdditionalCustomHeaders());

    if (request.IsEventStreamRequest())
    {
        httpRequest->AddContentBody(request.GetBody());
    }
    else
    {
        //Check if compression is required
        CompressionAlgorithm selectedCompressionAlgorithm =
            request.GetSelectedCompressionAlgorithm(m_requestCompressionConfig);
        if (Aws::Client::CompressionAlgorithm::NONE != selectedCompressionAlgorithm) {
            Aws::Client::RequestCompression rc;
            auto compressOutcome = rc.compress(request.GetBody(), selectedCompressionAlgorithm);

            if (compressOutcome.IsSuccess()) {
                Aws::String compressionAlgorithmId = Aws::Client::GetCompressionAlgorithmId(selectedCompressionAlgorithm);
                AppendHeaderValueToRequest(httpRequest, CONTENT_ENCODING_HEADER, compressionAlgorithmId);
                if (selectedCompressionAlgorithm == Aws::Client::CompressionAlgorithm::GZIP) {
                  request.AddUserAgentFeature(Aws::Client::UserAgentFeature::GZIP_REQUEST_COMPRESSION);
                }
                AddContentBodyToRequest(
                    httpRequest, compressOutcome.GetResult(),
                    request.ShouldComputeContentMd5(),
                    request.IsStreaming() && request.IsChunked() &&
                        m_httpClient->SupportsChunkedTransferEncoding());
            } else {
                AWS_LOGSTREAM_ERROR(AWS_CLIENT_LOG_TAG, "Failed to compress request, submitting uncompressed");
                AddContentBodyToRequest(httpRequest, request.GetBody(), request.ShouldComputeContentMd5(), request.IsStreaming() && request.IsChunked() && m_httpClient->SupportsChunkedTransferEncoding());
            }
        } else {
            AddContentBodyToRequest(httpRequest, request.GetBody(), request.ShouldComputeContentMd5(), request.IsStreaming() && request.IsChunked() && m_httpClient->SupportsChunkedTransferEncoding());
        }
    }

    if (httpRequest->HasHeader(Aws::Http::SMITHY_PROTOCOL_HEADER))
    {
        request.AddUserAgentFeature(Aws::Client::UserAgentFeature::PROTOCOL_RPC_V2_CBOR);
    }

    if (request.IsStreaming() && !m_disableExpectHeader)
    {
        httpRequest->SetHeaderValue(Aws::Http::EXPECT_HEADER, Aws::Http::EXPECT_100_CONTINUE_VALUE);
    }

    // Pass along handlers for processing data sent/received in bytes
    httpRequest->SetHeadersReceivedEventHandler(request.GetHeadersReceivedEventHandler());
    httpRequest->SetDataReceivedEventHandler(request.GetDataReceivedEventHandler());
    httpRequest->SetDataSentEventHandler(request.GetDataSentEventHandler());
    httpRequest->SetContinueRequestHandle(request.GetContinueRequestHandler());
    httpRequest->SetServiceSpecificParameters(request.GetServiceSpecificParameters());
    request.AddQueryStringParameters(httpRequest->GetUri());

    // check for retry context, if present use it
    RetryContext context = request.GetRetryContext();
    if (context.m_requestHash != nullptr) {
      const auto hash = Aws::MakeShared<Aws::Utils::Crypto::PrecalculatedHash>(smithy::client::AWS_SMITHY_CLIENT_CHECKSUM, HashingUtils::Base64Encode(context.m_requestHash->second->GetHash().GetResult()));
      httpRequest->SetRequestHash(context.m_requestHash->first, hash);
    }
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const Aws::Http::HeaderValueCollection& customizedHeaders, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, customizedHeaders, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const Aws::Http::HeaderValueCollection& customizedHeaders, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, customizedHeaders, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const char* serviceName, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, serviceName, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const char* serviceName, const Aws::Http::HeaderValueCollection& customizedHeaders, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, serviceName, customizedHeaders, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const char* serviceName, const char* signerName, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, serviceName, signerName, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const char* serviceName, const char* signerName, const Aws::Http::HeaderValueCollection& customizedHeaders, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(uri, method, region, serviceName, signerName, customizedHeaders, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::Endpoint::AWSEndpoint& endpoint,
                                            Aws::Http::HttpMethod method /* = Http::HttpMethod::HTTP_POST */,
                                            const Aws::Http::HeaderValueCollection& customizedHeaders /* = {} */,
                                            uint64_t expirationInSeconds /* = 0 */,
                                            const char* signerName /* = Aws::Auth::SIGV4_SIGNER */,
                                            const char* signerRegionOverride /* = nullptr */,
                                            const char* signerServiceNameOverride /* = nullptr */,
                                            const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter)
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(endpoint, method, customizedHeaders, expirationInSeconds, signerName, signerRegionOverride, signerServiceNameOverride, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::AmazonWebServiceRequest& request, const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region,
    const Aws::Http::QueryStringParameterCollection& extraParams, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(request, uri, method, region, extraParams, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::AmazonWebServiceRequest& request, const Aws::Http::URI& uri, Aws::Http::HttpMethod method, const char* region, const char* serviceName,
    const Aws::Http::QueryStringParameterCollection& extraParams, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(request, uri, method, region, serviceName, extraParams, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::AmazonWebServiceRequest& request,
                                            const Aws::Http::URI& uri,
                                            Aws::Http::HttpMethod method,
                                            const char* region,
                                            const char* serviceName,
                                            const char* signerName,
                                            const Aws::Http::QueryStringParameterCollection& extraParams,
                                            long long expirationInSeconds,
                                            const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(request, uri, method, region, serviceName, signerName, extraParams, expirationInSeconds, serviceSpecificParameter);
}

Aws::String AWSClient::GeneratePresignedUrl(const Aws::AmazonWebServiceRequest& request, const Aws::Http::URI& uri, Aws::Http::HttpMethod method,
    const Aws::Http::QueryStringParameterCollection& extraParams, long long expirationInSeconds, const std::shared_ptr<Aws::Http::ServiceSpecificParameters> serviceSpecificParameter) const
{
    return AWSUrlPresigner(*this).GeneratePresignedUrl(request, uri, method, extraParams, expirationInSeconds, serviceSpecificParameter);
}

std::shared_ptr<Aws::Http::HttpResponse> AWSClient::MakeHttpRequest(std::shared_ptr<Aws::Http::HttpRequest>& request) const
{
    return m_httpClient->MakeRequest(request, m_readRateLimiter.get(), m_writeRateLimiter.get());
}

void AWSClient::AppendRecursionDetectionHeader(std::shared_ptr<Aws::Http::HttpRequest> ioRequest)
{
    if(!ioRequest || ioRequest->HasHeader(Aws::Http::X_AMZN_TRACE_ID_HEADER)) {
        return;
    }
    Aws::String awsLambdaFunctionName = Aws::Environment::GetEnv(AWS_LAMBDA_FUNCTION_NAME);
    if(awsLambdaFunctionName.empty()) {
        return;
    }
    Aws::String xAmznTraceIdVal = Aws::Environment::GetEnv(X_AMZN_TRACE_ID);
    if(xAmznTraceIdVal.empty()) {
        return;
    }

    // Escape all non-printable ASCII characters by percent encoding
    Aws::OStringStream xAmznTraceIdValEncodedStr;
    for(const char ch : xAmznTraceIdVal)
    {
        if (ch >= 0x20 && ch <= 0x7e) // ascii chars [32-126] or [' ' to '~'] are not escaped
        {
            xAmznTraceIdValEncodedStr << ch;
        }
        else
        {
            // A percent-encoded octet is encoded as a character triplet
            xAmznTraceIdValEncodedStr << '%' // consisting of the percent character "%"
                                      << std::hex << std::setfill('0') << std::setw(2) << std::uppercase
                                      << (size_t) ch //followed by the two hexadecimal digits representing that octet's numeric value
                                      << std::dec << std::setfill(' ') << std::setw(0) << std::nouppercase;
        }
    }
    xAmznTraceIdVal = xAmznTraceIdValEncodedStr.str();

    ioRequest->SetHeaderValue(Aws::Http::X_AMZN_TRACE_ID_HEADER, xAmznTraceIdVal);
}